#!/usr/bin/env python3
"""Build the OFFICIAL ONI index via PCA (proposal section 4.1 Phase D primary
weighting method: "First Principal Component of the narrative dimensions"),
now that the full 1,790-doc corpus is annotated (stable N for PCA, unlike
earlier small-sample tests).

PCA is run on the 4 CORE reliable fields only (see DECISIONS.md 2026-07-25/26
ICC/kappa validation for why the other 4 are excluded from the primary index).
forward_guidance_direction (string) is mapped to numeric {-1,0,1} first.

Usage:
  python 04_experiments/annotation/build_oni_pca.py 03_data/derived/annotations/llama3.3_70b_annotations.jsonl
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from sklearn.decomposition import PCA

DIRECTION_MAP = {"cut": -1, "maintain": 0, "increase": 1}
CORE_FIELDS = ["sentiment_hawkish", "forward_guidance_direction_numeric",
               "demand_outlook_tone", "price_outlook_tone"]


def load_records(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.open(encoding="utf-8") if line.strip()]


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: build_oni_pca.py <annotations.jsonl>", file=sys.stderr)
        return 1
    path = Path(sys.argv[1])
    recs = load_records(path)
    n = len(recs)
    print(f"N = {n} documents")

    fwd = np.array([DIRECTION_MAP[r["forward_guidance_direction"]] for r in recs])
    matrix = np.column_stack([
        [r["sentiment_hawkish"] for r in recs],
        fwd,
        [r["demand_outlook_tone"] for r in recs],
        [r["price_outlook_tone"] for r in recs],
    ]).astype(float)

    means = matrix.mean(axis=0)
    sds = matrix.std(axis=0, ddof=0)
    sds[sds == 0] = 1
    z = (matrix - means) / sds

    pca = PCA(n_components=len(CORE_FIELDS))
    pcs = pca.fit_transform(z)
    print("\nExplained variance ratio by component:", np.round(pca.explained_variance_ratio_, 3))
    print("PC1 loadings:")
    for f, w in zip(CORE_FIELDS, pca.components_[0]):
        print(f"  {f:32s} {w:+.3f}")

    pc1 = pcs[:, 0]
    # Orient PC1 so higher = more hawkish (align sign with sentiment_hawkish loading)
    if pca.components_[0][0] < 0:
        pc1 = -pc1
        print("(PC1 sign flipped so positive = hawkish, matching sentiment_hawkish direction)")

    oni_pca = (pc1 - pc1.mean()) / pc1.std()  # standardize to mean0 sd1 for interpretability

    equalweight = z.mean(axis=1)
    corr = np.corrcoef(oni_pca, equalweight)[0, 1]
    print(f"\nONI_pca: mean={oni_pca.mean():+.3f} sd={oni_pca.std():.3f} range=[{oni_pca.min():+.3f}, {oni_pca.max():+.3f}]")
    print(f"Correlation(ONI_pca, ONI_core equal-weight) = {corr:.3f}")

    out_path = path.parent / f"{path.stem}_oni_pca.jsonl"
    with out_path.open("w", encoding="utf-8") as handle:
        for r, p, e in zip(recs, oni_pca, equalweight):
            handle.write(json.dumps({"doc_id": r["doc_id"], "ONI_pca": round(float(p), 4),
                                      "ONI_core_equalweight": round(float(e), 4)}) + "\n")
    print(f"\nWrote {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
