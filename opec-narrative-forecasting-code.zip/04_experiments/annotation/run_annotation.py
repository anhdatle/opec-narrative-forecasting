#!/usr/bin/env python3
"""Local-LLM narrative annotation pipeline for the OPEC Narrative Index (ONI) corpus.

Calls a locally-hosted Ollama model per document, validates the response against
oni_extraction_schema_v1.json, retries on schema failure, and writes resumable,
checkpointed output. Designed to run unattended (e.g. under `caffeinate -i`) for
the full ~2,800-document corpus without burning conversational-agent tokens.

Two input modes:
  --manifest <jsonl>   real corpus mode: each line is {"doc_id", "local_path", ...}
  --text-dir <dir>     simple mode: annotate every *.txt file in a directory,
                        doc_id = filename stem (used for smoke tests before the
                        scraper-built manifest exists)

Usage:
  run_annotation.py --model llama3.3:70b --text-dir smoke_test_fixtures --limit 5
  run_annotation.py --model llama3.3:70b --manifest ../../03_data/manifest/document_index.jsonl
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

import jsonschema
import requests

REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_SCHEMA = REPO_ROOT / "02_method/prompts/oni_extraction_schema_v1.json"
DEFAULT_MANIFEST = REPO_ROOT / "03_data/manifest/document_index.jsonl"
DERIVED_DIR = REPO_ROOT / "03_data/derived"
CHECKPOINT_DIR = Path(__file__).resolve().parent
LOG_DIR = Path(__file__).resolve().parent / "logs"
OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434")

SYSTEM_PROMPT = (
    "You are an oil market analyst with expertise in OPEC communications. Analyze "
    "the OPEC communication provided by the user and extract structured information "
    "about its narrative content. Base every field strictly on the text provided — "
    "do not use outside knowledge of how markets reacted to this event, and do not "
    "guess a date or outcome that is not present in the text. "
    "Scale reminder: commitment_credibility, internal_cohesion, and "
    "forward_guidance_clarity are each scored on a 0-to-10 scale, NOT 0-to-1 — use "
    "the full range (e.g. a weak, hedged commitment should score near 1-3, not near "
    "0, and a strong unambiguous one should score near 8-10, not 1.0). The "
    "sentiment/tone fields (sentiment_hawkish, sentiment_dovish, demand_outlook_tone, "
    "supply_outlook_tone, price_outlook_tone) use a separate -1-to-+1 scale. Do not "
    "confuse the two scales. "
    "forward_guidance_direction is a STRING, one of \"cut\", \"maintain\", or "
    "\"increase\" — not a number. First identify the specific sentence stating the "
    "production change, then choose the label matching that sentence. Do not choose a "
    "label first and justify it afterward: a common error is extracting text that says "
    "'adjust downwards' or 'cut' and then inconsistently labeling the direction as "
    "'increase' (or vice versa) — double check your label is not the opposite of your "
    "own evidence. "
    "Return only a single JSON object matching the required schema. No prose outside "
    "the JSON."
)

# Heuristic strip patterns for --blind mode (hindsight-leakage mitigation).
# Not perfect NLP date-detection — good enough to remove the obvious tells
# (ordinal meeting names, explicit dates/years) that let a model "recognize"
# a famous OPEC event instead of reading the text fresh.
BLIND_PATTERNS = [
    re.compile(r"\b\d{1,3}(st|nd|rd|th)\s+(Ordinary|Extraordinary)\s+Meeting\b", re.I),
    re.compile(r"\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2},?\s*(19|20)\d{2}\b", re.I),
    re.compile(r"\b(19|20)\d{2}\b"),
]


def write_json_atomic(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        handle.write(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
    os.replace(tmp, path)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_text(path.read_text(encoding="utf-8"))


def blind_text(text: str) -> str:
    for pattern in BLIND_PATTERNS:
        text = pattern.sub("[REDACTED]", text)
    return text


def load_schema(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def load_documents(args: argparse.Namespace) -> list[dict]:
    docs: list[dict] = []
    if args.text_dir:
        text_dir = Path(args.text_dir)
        for fp in sorted(text_dir.glob("*.txt")):
            docs.append({"doc_id": fp.stem, "local_path": str(fp), "source_type": "smoke_test"})
    else:
        manifest_path = Path(args.manifest)
        if not manifest_path.exists():
            print(f"ERROR: manifest not found: {manifest_path}", file=sys.stderr)
            sys.exit(1)
        with manifest_path.open(encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if line:
                    docs.append(json.loads(line))
    if args.limit:
        docs = docs[: args.limit]
    return docs


def get_processed_ids(annotations_path: Path) -> set[str]:
    if not annotations_path.exists():
        return set()
    ids = set()
    with annotations_path.open(encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                ids.add(json.loads(line)["doc_id"])
            except (json.JSONDecodeError, KeyError):
                continue
    return ids


def get_git_commit() -> str:
    try:
        out = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=REPO_ROOT, capture_output=True, text=True, timeout=5, check=True,
        )
        return out.stdout.strip()
    except Exception:  # noqa: BLE001
        return "unknown"


def get_ollama_model_info(model: str) -> dict:
    info: dict = {}
    try:
        show_resp = requests.post(f"{OLLAMA_URL}/api/show", json={"name": model}, timeout=15)
        show_resp.raise_for_status()
        show_data = show_resp.json()
        info["details"] = show_data.get("details", {})
    except Exception as exc:  # noqa: BLE001
        info["show_error"] = str(exc)
    try:
        tags_resp = requests.get(f"{OLLAMA_URL}/api/tags", timeout=15)
        tags_resp.raise_for_status()
        for m in tags_resp.json().get("models", []):
            if m.get("name") == model:
                info["digest"] = m.get("digest")
                info["size_bytes"] = m.get("size")
                info["modified_at"] = m.get("modified_at")
                break
    except Exception as exc:  # noqa: BLE001
        info["tags_error"] = str(exc)
    return info


def get_ollama_version() -> str:
    try:
        resp = requests.get(f"{OLLAMA_URL}/api/version", timeout=5)
        return resp.json().get("version", "unknown")
    except Exception:  # noqa: BLE001
        return "unknown"


def call_ollama_chat(model: str, messages: list[dict], schema: dict, timeout: int) -> tuple[str, dict]:
    payload = {
        "model": model,
        "messages": messages,
        "format": schema,
        "options": {"temperature": 0.0},
        "stream": False,
    }
    resp = requests.post(f"{OLLAMA_URL}/api/chat", json=payload, timeout=timeout)
    resp.raise_for_status()
    data = resp.json()
    content = data.get("message", {}).get("content", "")
    return content, data


def annotate_document(
    model: str, document_text: str, schema: dict, max_retries: int, timeout: int,
    system_prompt: str = SYSTEM_PROMPT,
) -> tuple[dict | None, list[str], str | None]:
    """Returns (parsed_record_or_None, raw_response_strings, error_or_None)."""
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"TEXT:\n{document_text}"},
    ]
    raw_responses: list[str] = []
    last_error = None
    for attempt in range(1, max_retries + 1):
        try:
            content, _ = call_ollama_chat(model, messages, schema, timeout)
        except Exception as exc:  # noqa: BLE001
            last_error = f"request_error: {exc}"
            time.sleep(min(2**attempt, 10))
            continue
        raw_responses.append(content)
        try:
            parsed = json.loads(content)
            jsonschema.validate(parsed, schema)
            return parsed, raw_responses, None
        except (json.JSONDecodeError, jsonschema.ValidationError) as exc:
            last_error = f"validation_error: {exc}"
            messages.append({"role": "assistant", "content": content})
            messages.append(
                {
                    "role": "user",
                    "content": f"Your last response did not match the required JSON schema: {exc}. "
                    "Return only corrected JSON, no other text.",
                }
            )
    return None, raw_responses, last_error


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--model", required=True, help="Ollama model tag, e.g. llama3.3:70b")
    parser.add_argument("--manifest", default=str(DEFAULT_MANIFEST))
    parser.add_argument("--text-dir", default=None, help="Simple mode: annotate *.txt files in this dir")
    parser.add_argument("--schema", default=str(DEFAULT_SCHEMA))
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--blind", action="store_true")
    parser.add_argument("--sleep", type=float, default=0.0, help="Seconds to sleep between documents")
    parser.add_argument("--max-retries", type=int, default=3)
    parser.add_argument("--timeout", type=int, default=180, help="Per-request timeout in seconds")
    parser.add_argument("--out-tag", default=None, help="Override output subdir name (default: sanitized model tag)")
    parser.add_argument("--system-prompt-file", default=None,
                         help="Override the ONI system prompt with a plain-text file (for reusing this pipeline "
                              "with a different extraction schema, e.g. delta_q extraction)")
    args = parser.parse_args()

    out_tag = args.out_tag or args.model.replace(":", "_").replace("/", "_")
    if args.blind:
        out_tag += "__blind"

    schema = load_schema(Path(args.schema))
    system_prompt = Path(args.system_prompt_file).read_text(encoding="utf-8") if args.system_prompt_file else SYSTEM_PROMPT
    docs = load_documents(args)
    if not docs:
        print("No documents found to annotate.", file=sys.stderr)
        return 1

    raw_dir = DERIVED_DIR / "llm_raw" / out_tag
    annotations_path = DERIVED_DIR / "annotations" / f"{out_tag}_annotations.jsonl"
    checkpoint_path = CHECKPOINT_DIR / f"checkpoint_{out_tag}.json"
    log_path = LOG_DIR / f"{out_tag}_run.log"
    raw_dir.mkdir(parents=True, exist_ok=True)
    annotations_path.parent.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    already_done = get_processed_ids(annotations_path)
    todo = [d for d in docs if d["doc_id"] not in already_done]
    print(f"Total docs: {len(docs)} | already annotated: {len(already_done)} | to process: {len(todo)}")

    run_manifest_path = CHECKPOINT_DIR / f"run_manifest_{out_tag}_{datetime.now(timezone.utc).strftime('%Y%m%d')}.json"
    run_manifest = {
        "model": args.model,
        "blind_mode": args.blind,
        "ollama_version": get_ollama_version(),
        "ollama_model_info": get_ollama_model_info(args.model),
        "prompt_schema_sha256": sha256_file(Path(args.schema)),
        "git_commit": get_git_commit(),
        "hardware_profile_path": str(REPO_ROOT / "04_experiments/00_setup/hardware_profile.json"),
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "docs_total": len(docs),
        "docs_processed": 0,
        "docs_failed": 0,
    }
    write_json_atomic(run_manifest_path, run_manifest)

    n_ok, n_fail = 0, 0
    t_start = time.monotonic()
    log_handle = log_path.open("a", encoding="utf-8")

    with annotations_path.open("a", encoding="utf-8") as ann_handle:
        for i, doc in enumerate(todo, start=1):
            doc_id = doc["doc_id"]
            local_path = Path(doc["local_path"])
            if not local_path.is_absolute():
                local_path = REPO_ROOT / local_path
            if not local_path.exists():
                msg = f"SKIP {doc_id}: local_path not found: {local_path}"
                print(msg)
                log_handle.write(msg + "\n")
                n_fail += 1
                continue

            text = local_path.read_text(encoding="utf-8", errors="ignore")
            text_for_model = blind_text(text) if args.blind else text

            t0 = time.monotonic()
            record, raw_responses, error = annotate_document(
                args.model, text_for_model, schema, args.max_retries, args.timeout,
                system_prompt=system_prompt,
            )
            elapsed = time.monotonic() - t0

            (raw_dir / f"{doc_id}.json").write_text(
                json.dumps({"attempts": raw_responses, "error": error}, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )

            if record is None:
                n_fail += 1
                log_line = f"FAIL {doc_id}: {error}"
                print(log_line)
                log_handle.write(log_line + "\n")
            else:
                n_ok += 1
                out_record = {
                    "doc_id": doc_id,
                    "source_type": doc.get("source_type"),
                    "meeting_id": doc.get("meeting_id"),
                    "meeting_date": doc.get("meeting_date"),
                    "text_sha256": sha256_text(text),
                    "blind_mode": args.blind,
                    "model": args.model,
                    "annotated_at_utc": datetime.now(timezone.utc).isoformat(),
                    "latency_seconds": round(elapsed, 2),
                    **record,
                }
                ann_handle.write(json.dumps(out_record, ensure_ascii=False) + "\n")
                ann_handle.flush()

            if i % 5 == 0 or i == len(todo):
                elapsed_total = time.monotonic() - t_start
                docs_per_hour = (n_ok + n_fail) / elapsed_total * 3600 if elapsed_total > 0 else 0
                checkpoint = {
                    "updated_at_utc": datetime.now(timezone.utc).isoformat(),
                    "processed_this_run": n_ok + n_fail,
                    "ok": n_ok,
                    "failed": n_fail,
                    "remaining": len(todo) - i,
                    "docs_per_hour": round(docs_per_hour, 2),
                }
                write_json_atomic(checkpoint_path, checkpoint)
                print(
                    f"[{i}/{len(todo)}] ok={n_ok} fail={n_fail} "
                    f"throughput={docs_per_hour:.1f} docs/hr"
                )

            if args.sleep:
                time.sleep(args.sleep)

    run_manifest.update(
        {
            "finished_at_utc": datetime.now(timezone.utc).isoformat(),
            "docs_processed": n_ok,
            "docs_failed": n_fail,
        }
    )
    write_json_atomic(run_manifest_path, run_manifest)
    log_handle.close()

    print(f"\nDone. ok={n_ok} fail={n_fail}. Annotations: {annotations_path}")
    print(f"Run manifest: {run_manifest_path}")
    return 0 if n_fail == 0 else (0 if n_ok > 0 else 1)


if __name__ == "__main__":
    raise SystemExit(main())
