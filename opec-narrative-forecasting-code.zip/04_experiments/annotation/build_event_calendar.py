#!/usr/bin/env python3
"""Build a deduplicated OPEC Event Calendar (real Δq series) from the Δq
extraction pass, replacing the 11-date hardcoded table used earlier.

Falls back to the document's own meeting_date (parsed from the press-release
URL slug by the scraper) when the LLM couldn't find an explicit decision_date
in the text. Flags same-date entries with conflicting delta_q for manual
review rather than silently picking one.

Usage:
  python 04_experiments/annotation/build_event_calendar.py
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from dateutil import parser as dtparser

REPO_ROOT = Path(__file__).resolve().parents[2]
ANNOTATIONS = REPO_ROOT / "03_data/derived/annotations/llama3.3_70b_deltaq_annotations.jsonl"
MANIFEST = REPO_ROOT / "03_data/manifest/document_index.jsonl"
OUT_PATH = Path(__file__).resolve().parent / "event_calendar.json"
ADJUDICATIONS = Path(__file__).resolve().parent / "policy_target_machine_adjudications.json"

MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], start=1)}


def parse_slug_date(slug: str | None) -> str | None:
    if not slug:
        return None
    m = re.match(r"(\d{1,2})-([a-z]+)-(\d{4})", slug, re.I)
    if not m:
        return None
    day, mon_str, year = m.groups()
    mon = MONTHS.get(mon_str[:3].lower())
    if not mon:
        return None
    return f"{year}-{mon:02d}-{int(day):02d}"


def parse_free_date(raw: str | None) -> str | None:
    if not raw:
        return None
    try:
        dt = dtparser.parse(raw, default=None, fuzzy=True)
        return dt.date().isoformat()
    except (ValueError, OverflowError):
        return None


def main() -> int:
    manifest_by_id = {json.loads(l)["doc_id"]: json.loads(l) for l in MANIFEST.open(encoding="utf-8")}
    recs = [json.loads(l) for l in ANNOTATIONS.open(encoding="utf-8")]
    decisions = [r for r in recs if r["is_production_decision"]]
    adjudications = {}
    if ADJUDICATIONS.exists():
        payload = json.loads(ADJUDICATIONS.read_text(encoding="utf-8"))
        adjudications = {row["doc_id"]: row for row in payload.get("adjudications", [])}

    resolved = []
    unresolved_date = []
    for r in decisions:
        iso = parse_free_date(r.get("decision_date"))
        source = "llm_decision_date"
        if iso is None:
            doc = manifest_by_id.get(r["doc_id"], {})
            iso = parse_slug_date(doc.get("meeting_date"))
            source = "scraper_slug_fallback"
        if iso is None:
            unresolved_date.append(r["doc_id"])
            continue
        original_type = r["decision_type"]
        audit = adjudications.get(r["doc_id"])
        if audit is not None:
            r = {**r, "decision_type": audit["adjudicated_decision_type"]}
        resolved.append({
            **r,
            "_iso_date": iso,
            "_date_source": source,
            "_original_decision_type": original_type,
            "_machine_adjudication": audit,
        })

    by_date: dict[str, list[dict]] = {}
    for r in resolved:
        by_date.setdefault(r["_iso_date"], []).append(r)

    calendar = []
    conflicts = []
    for date, group in sorted(by_date.items()):
        dqs = {round(g["delta_q_mb_d"], 3) for g in group if g["delta_q_mb_d"] is not None}
        if len(dqs) > 1:
            conflicts.append({"date": date, "doc_ids": [g["doc_id"] for g in group],
                               "delta_qs": sorted(dqs)})
            continue
        dq = next(iter(dqs)) if dqs else None
        extracted_types = sorted({g["_original_decision_type"] for g in group})
        retained_types = sorted({g["decision_type"] for g in group})
        if len(retained_types) != 1:
            conflicts.append({
                "date": date,
                "doc_ids": [g["doc_id"] for g in group],
                "decision_types": retained_types,
                "reason": "same-date decision-class conflict",
            })
            continue
        audits = [g["_machine_adjudication"] for g in group if g["_machine_adjudication"]]
        retained_type = retained_types[0]
        if dq is None:
            normalized_dq = None
        elif retained_type == "maintain":
            normalized_dq = 0.0
        elif retained_type == "cut":
            normalized_dq = -abs(dq)
        else:
            normalized_dq = abs(dq)
        calendar.append({
            "date": date,
            "delta_q_mb_d": dq,
            "normalized_action_delta_q_mb_d": normalized_dq,
            "decision_type": retained_type,
            "original_extracted_decision_types": extracted_types,
            "n_docs": len(group),
            "doc_ids": [g["doc_id"] for g in group],
            "date_source": group[0]["_date_source"],
            "label_source": "machine_adjudicated" if audits else "llm_extracted_unvalidated",
            "machine_adjudication_ids": [a["adjudication_id"] for a in audits],
            "human_validated": False,
        })

    OUT_PATH.write_text(json.dumps({
        "target_definition": {
            "cut": "a new net reduction relative to the immediately preceding effective production path",
            "maintain": "no new net change, including an extension or reaffirmation of an existing adjustment",
            "increase": "a new net addition or phase-out relative to the immediately preceding effective production path",
        },
        "measurement_status": "LLM-extracted labels with transparent machine adjudications; independent human validation pending",
        "quantity_normalization": "maintain actions are assigned zero net-new change; cut/increase quantities receive the sign of the retained action class; raw extracted delta_q_mb_d is preserved",
        "events": calendar,
        "conflicts": conflicts,
        "unresolved_date_doc_ids": unresolved_date,
    }, indent=2))

    print(f"Total decisions extracted: {len(decisions)}")
    print(f"Resolved to a date: {len(resolved)}  |  unresolved (no date found): {len(unresolved_date)}")
    print(f"Unique event-dates after dedup: {len(calendar)}  |  date conflicts flagged: {len(conflicts)}")
    print(f"\nDate source breakdown: "
          f"{sum(1 for r in resolved if r['_date_source']=='llm_decision_date')} from LLM decision_date, "
          f"{sum(1 for r in resolved if r['_date_source']=='scraper_slug_fallback')} from scraper URL fallback")
    if conflicts:
        print("\nCONFLICTS (same date, different Δq across docs) — needs manual review:")
        for c in conflicts:
            print(f"  {c['date']}: {c['delta_qs']}  docs={c['doc_ids']}")
    print(f"\nWrote {OUT_PATH}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
