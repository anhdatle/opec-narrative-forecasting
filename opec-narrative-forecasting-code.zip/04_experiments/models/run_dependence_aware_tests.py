#!/usr/bin/env python3
"""Dependence-aware paired inference for Macro-F1 differences.

Reports circular moving-block bootstrap intervals and blockwise label-swap
randomization p-values. Block lengths are sensitivity choices, not tuned.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
TREND = ROOT / "04_experiments/models/trend_classification_results.json"
FUSION = ROOT / "05_results/nested_rag_fusion.json"
OUT = ROOT / "05_results/dependence_aware_forecast_tests.json"
RAG = {
    "price": ROOT / "04_experiments/models/rag_llm_price_llama3.3_70b_tfidf_v2.jsonl",
    "production": ROOT / "04_experiments/models/rag_llm_production_llama3.3_70b_tfidf_v2.jsonl",
}
LABELS = {"price": ["down", "neutral", "up"], "production": ["cut", "maintain", "increase"]}


def macro_f1(y, prediction, labels):
    score = 0.0
    for label in labels:
        truth = y == label
        chosen = prediction == label
        true_positive = int(np.sum(truth & chosen))
        false_positive = int(np.sum(~truth & chosen))
        false_negative = int(np.sum(truth & ~chosen))
        denominator = 2 * true_positive + false_positive + false_negative
        score += 0.0 if denominator == 0 else 2 * true_positive / denominator
    return score / len(labels)


def circular_block_indices(n: int, block_length: int, rng: np.random.Generator) -> np.ndarray:
    blocks = int(np.ceil(n / block_length))
    starts = rng.integers(0, n, size=blocks)
    return np.concatenate([
        (start + np.arange(block_length)) % n for start in starts
    ])[:n]


def block_bootstrap(y, candidate, baseline, labels, block_length, draws=20_000, seed=20260824):
    rng = np.random.default_rng(seed + block_length)
    deltas = np.empty(draws, dtype=float)
    for draw in range(draws):
        index = circular_block_indices(len(y), block_length, rng)
        deltas[draw] = (
            macro_f1(y[index], candidate[index], labels)
            - macro_f1(y[index], baseline[index], labels)
        )
    return [float(value) for value in np.quantile(deltas, [0.025, 0.975])]


def block_swap_test(y, candidate, baseline, labels, block_length, draws=50_000, seed=20260824):
    observed = macro_f1(y, candidate, labels) - macro_f1(y, baseline, labels)
    blocks = [np.arange(start, min(start + block_length, len(y))) for start in range(0, len(y), block_length)]
    rng = np.random.default_rng(seed + 100 * block_length)
    extreme = 0
    for _ in range(draws):
        swap = rng.integers(0, 2, size=len(blocks)).astype(bool)
        a, b = candidate.copy(), baseline.copy()
        for do_swap, index in zip(swap, blocks):
            if do_swap:
                a[index], b[index] = baseline[index], candidate[index]
        delta = macro_f1(y, a, labels) - macro_f1(y, b, labels)
        extreme += abs(delta) >= abs(observed) - 1e-15
    return float((extreme + 1) / (draws + 1))


def load_task(task, trend, fusion):
    key = "price_trend" if task == "price" else "production_trend"
    base = trend[key]["predictions"]["Persistence"]
    origin_to_position = {origin: i for i, origin in enumerate(base["target_dates"])}
    order = base["target_dates"]
    candidates = {
        name: values["y_pred"]
        for name, values in trend[key]["predictions"].items()
        if name != "Persistence"
    }
    rag_rows = [json.loads(line) for line in RAG[task].read_text().splitlines() if line.strip()]
    candidates["Pure RAG-LLM raw official text"] = [
        next(row["prediction"]["forecast_label"] for row in rag_rows if row["origin_id"] == origin)
        for origin in order
    ]
    primary = fusion["tasks"][task]["variants"]["history_plus_rag_weight_0.50"]
    candidates["History + RAG fixed 0.50 pool"] = [
        primary["predictions"][primary["target_dates"].index(origin)] for origin in order
    ]
    return np.asarray(base["y_true"], dtype=object), np.asarray(base["y_pred"], dtype=object), candidates


def main():
    trend = json.loads(TREND.read_text())
    fusion = json.loads(FUSION.read_text())
    result = {
        "method": "circular moving-block bootstrap CI and non-overlapping block label-swap randomization",
        "block_lengths": [3, 6, 12],
        "bootstrap_draws": 20000,
        "randomization_draws": 50000,
        "tasks": {},
    }
    for task in ("price", "production"):
        y, baseline, candidates = load_task(task, trend, fusion)
        task_result = {}
        for name, values in candidates.items():
            candidate = np.asarray(values, dtype=object)
            task_result[name] = {
                "macro_f1_difference_vs_persistence": macro_f1(y, candidate, LABELS[task]) - macro_f1(y, baseline, LABELS[task]),
                "by_block_length": {
                    str(length): {
                        "moving_block_bootstrap_ci95": block_bootstrap(y, candidate, baseline, LABELS[task], length),
                        "block_swap_two_sided_p": block_swap_test(y, candidate, baseline, LABELS[task], length),
                    }
                    for length in (3, 6, 12)
                },
            }
        result["tasks"][task] = task_result
    OUT.write_text(json.dumps(result, indent=2) + "\n")
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
