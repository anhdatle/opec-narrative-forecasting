#!/usr/bin/env python3
"""Pure retrieval-augmented LLM classifier for the OPEC trend tasks.

This is deliberately separate from the ONI pipeline: it supplies retrieved raw
official text directly to an LLM and contains no ONI/PCA score, market feature,
or downstream ML classifier. Retrieval is lexical TF-IDF/BM25-like ranking over
documents that pass the same conservative timing gates as the classification
dataset. Every forecast saves its prompt-relevant evidence IDs and raw LLM JSON.

Examples:
  # Audit retrieval without making an LLM call.
  python run_rag_llm_classifier.py --task price --dry-run --limit 2
  # Smoke test two expanding-window forecast origins.
  python run_rag_llm_classifier.py --task price --model llama3.3:70b --limit 2
  # Run all out-of-sample origins, resumably.
  python run_rag_llm_classifier.py --task production --model llama3.3:70b
"""
from __future__ import annotations

import argparse
import calendar
import json
import os
import re
import sys
import time
from datetime import date
from pathlib import Path

import numpy as np
import requests
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel

sys.path.insert(0, str(Path(__file__).resolve().parent))
from run_trend_classification import (  # noqa: E402
    DECISION_LABELS, LABELS, build_price_task, build_production_task, parse_press_date,
)

REPO_ROOT = Path(__file__).resolve().parents[2]
MANIFEST_PATH = REPO_ROOT / "03_data/manifest/document_index.jsonl"
PROMPT_PATH = REPO_ROOT / "02_method/prompts/rag_classifier_system_prompt_v2.txt"
PROTOCOL_VERSION = "v2"
OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434")


def month_end(value: str) -> date:
    year, month = (int(x) for x in value.split("-"))
    return date(year, month, calendar.monthrange(year, month)[1])


def momr_month(record: dict) -> date | None:
    match = re.match(r"([A-Za-z]+)\s+(\d{4})", record.get("period_label", ""))
    if not match:
        return None
    name, year = match.groups()
    try:
        month = list(calendar.month_name).index(name.capitalize())
    except ValueError:
        return None
    return date(int(year), month, calendar.monthrange(int(year), month)[1])


def load_documents(task: str) -> list[dict]:
    docs = []
    for line in MANIFEST_PATH.read_text(encoding="utf-8").splitlines():
        record = json.loads(line)
        source_type = record.get("source_type")
        if task == "production" and source_type != "press_release":
            continue
        if source_type == "press_release":
            available = parse_press_date(record.get("meeting_date"))
        elif source_type == "momr_chapter":
            available = momr_month(record)
        else:
            available = None
        local_path = REPO_ROOT / record.get("local_path", "")
        if available is None or not local_path.exists():
            continue
        text = local_path.read_text(encoding="utf-8", errors="replace").strip()
        if text:
            docs.append({
                "doc_id": record["doc_id"], "source_type": source_type,
                "available_date": available, "title": record.get("title", record.get("chapter_title", "")),
                "text": text,
            })
    return sorted(docs, key=lambda x: x["available_date"])


def chunks(record: dict, width: int = 1800, overlap: int = 250) -> list[dict]:
    text = record["text"]
    out = []
    start = 0
    while start < len(text):
        piece = text[start:start + width].strip()
        if piece:
            out.append({**record, "chunk": piece})
        if start + width >= len(text):
            break
        start += width - overlap
    return out


def bm25_scores(corpus: list[str], query: str, k1: float = 1.5, b: float = 0.75) -> np.ndarray:
    tokenized = [re.findall(r"[A-Za-z0-9]+", text.lower()) for text in corpus]
    query_tokens = re.findall(r"[A-Za-z0-9]+", query.lower())
    lengths = np.asarray([len(tokens) for tokens in tokenized], dtype=float)
    average_length = float(lengths.mean()) if len(lengths) else 1.0
    document_frequency = {
        token: sum(token in set(document) for document in tokenized)
        for token in set(query_tokens)
    }
    scores = np.zeros(len(corpus), dtype=float)
    for index, document in enumerate(tokenized):
        frequencies = {token: document.count(token) for token in set(query_tokens)}
        for token in set(query_tokens):
            frequency = frequencies[token]
            if frequency == 0:
                continue
            df = document_frequency[token]
            idf = np.log(1.0 + (len(corpus) - df + 0.5) / (df + 0.5))
            denominator = frequency + k1 * (1.0 - b + b * lengths[index] / average_length)
            scores[index] += idf * frequency * (k1 + 1.0) / denominator
    return scores


def retrieve(candidates: list[dict], query: str, top_k: int, retriever: str = "tfidf") -> list[dict]:
    corpus = [f"{x['title']}\n{x['chunk']}" for x in candidates]
    if not corpus:
        return []
    if retriever == "bm25":
        scores = bm25_scores(corpus, query)
    else:
        vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), min_df=1, max_features=30000)
        matrix = vectorizer.fit_transform(corpus)
        scores = linear_kernel(vectorizer.transform([query]), matrix).ravel()
    ranked = np.argsort(-scores)
    selected, seen = [], set()
    for idx in ranked:
        item = candidates[int(idx)]
        # One best chunk per document keeps the evidence bundle diverse.
        if item["doc_id"] in seen:
            continue
        selected.append({
            "doc_id": item["doc_id"], "source_type": item["source_type"],
            "available_date": item["available_date"].isoformat(), "title": item["title"],
            "chunk": item["chunk"], "retrieval_score": round(float(scores[int(idx)]), 6),
        })
        seen.add(item["doc_id"])
        if len(selected) == top_k:
            break
    return selected


def schema(labels: list[str]) -> dict:
    return {
        "type": "object", "additionalProperties": False,
        "properties": {
            "forecast_label": {"type": "string", "enum": labels},
            "probabilities": {
                "type": "object", "additionalProperties": False,
                "properties": {label: {"type": "number", "minimum": 0, "maximum": 1} for label in labels},
                "required": labels,
            },
            "evidence_doc_ids": {"type": "array", "items": {"type": "string"}, "maxItems": 8},
            "rationale": {"type": "string", "maxLength": 900},
        },
        "required": ["forecast_label", "probabilities", "evidence_doc_ids", "rationale"],
    }


def call_llm(model: str, task_instruction: str, evidence: list[dict], labels: list[str], timeout: int, num_ctx: int) -> tuple[dict, dict]:
    evidence_text = "\n\n".join(
        f"[DOCUMENT {x['doc_id']} | {x['source_type']} | available {x['available_date']} | {x['title']}]\n{x['chunk']}"
        for x in evidence
    )
    user_prompt = f"""TASK: {task_instruction}
ALLOWED LABELS: {', '.join(labels)}

RETRIEVED OFFICIAL DOCUMENTS:\n{evidence_text}
"""
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": PROMPT_PATH.read_text(encoding="utf-8").strip()},
            {"role": "user", "content": user_prompt},
        ],
        "format": schema(labels),
        "options": {"temperature": 0.0, "num_ctx": num_ctx},
        "keep_alive": "30m",
        "stream": False,
    }
    if model.startswith("qwen3"):
        payload["think"] = False
    response = requests.post(f"{OLLAMA_URL}/api/chat", json=payload, timeout=timeout)
    response.raise_for_status()
    payload_response = response.json()
    parsed = json.loads(payload_response["message"]["content"])
    probabilities = parsed["probabilities"]
    total = sum(float(probabilities[x]) for x in labels)
    if not (0.99 <= total <= 1.01):
        raise ValueError(f"probabilities sum to {total}, not one")
    probability_argmax = max(labels, key=lambda label: float(probabilities[label]))
    if parsed["forecast_label"] != probability_argmax:
        parsed["reported_forecast_label"] = parsed["forecast_label"]
        parsed["forecast_label"] = probability_argmax
        parsed["label_probability_consistency_corrected"] = True
    else:
        parsed["label_probability_consistency_corrected"] = False
    retrieved_ids = {item["doc_id"] for item in evidence}
    if not set(parsed["evidence_doc_ids"]).issubset(retrieved_ids):
        raise ValueError("response cites a document outside the retrieved bundle")
    return parsed, {"user_prompt": user_prompt, "ollama": payload_response}


def task_rows(task: str):
    if task == "price":
        rows, labels, minimum = build_price_task(), LABELS, 48
        instruction = (
            "Forecast the next calendar month's WTI average-price log-return. "
            "Use down for return < -2%, neutral for return between -2% and +2% inclusive, "
            "and up for return > +2%."
        )
        for row in rows:
            row["cutoff_date"] = month_end(row["origin_month"])
        return rows, labels, minimum, instruction
    rows, labels, minimum = build_production_task(), DECISION_LABELS, 45
    instruction = (
        "Forecast the next retained OPEC production-policy action. Use cut for a new net reduction "
        "relative to the immediately preceding effective production path; maintain for no new net "
        "change, including an extension or reaffirmation of an existing adjustment; and increase for "
        "a new net addition or phase-out relative to the preceding path."
    )
    for row in rows:
        row["cutoff_date"] = date.fromisoformat(row["target_date"])
    return rows, labels, minimum, instruction


def available_candidates(docs: list[dict], task: str, row: dict) -> list[dict]:
    cutoff = row["cutoff_date"]
    if task == "price":
        # The full origin month must close before the next-month target. A six-
        # month retrieval window prevents distant archival language from crowding
        # out the current institutional assessment.
        lower = cutoff.fromordinal(cutoff.toordinal() - 180)
        allowed = [doc for doc in docs if lower <= doc["available_date"] <= cutoff]
    else:
        # Strictly before target date; target-day releases are excluded.
        lower = cutoff.fromordinal(cutoff.toordinal() - 180)
        allowed = [doc for doc in docs if lower <= doc["available_date"] < cutoff]
        if not allowed:
            older = [doc for doc in docs if doc["available_date"] < cutoff]
            allowed = older[-1:] if older else []
    result = []
    for doc in allowed:
        result.extend(chunks(doc))
    return result


def output_path(task: str, model: str, retriever: str) -> Path:
    tag = re.sub(r"[^A-Za-z0-9_.-]+", "_", model)
    return Path(__file__).resolve().parent / f"rag_llm_{task}_{tag}_{retriever}_{PROTOCOL_VERSION}.jsonl"


def processed_ids(path: Path) -> set[str]:
    if not path.exists():
        return set()
    return {json.loads(line)["origin_id"] for line in path.read_text(encoding="utf-8").splitlines() if line.strip()}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--task", choices=["price", "production"], required=True)
    parser.add_argument("--model", default="llama3.3:70b")
    parser.add_argument("--top-k", type=int, default=6)
    parser.add_argument("--retriever", choices=["tfidf", "bm25"], default="tfidf")
    parser.add_argument("--limit", type=int, default=None, help="Maximum out-of-sample origins to process")
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--num-ctx", type=int, default=8192)
    parser.add_argument("--dry-run", action="store_true", help="Write retrieval audit records without LLM calls")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    rows, labels, minimum, instruction = task_rows(args.task)
    test_rows = rows[minimum:]
    if args.limit:
        test_rows = test_rows[:args.limit]
    docs = load_documents(args.task)
    out = output_path(args.task, args.model, args.retriever)
    done = set() if args.overwrite else processed_ids(out)
    mode = "w" if args.overwrite else "a"
    query = (
        "oil price direction demand supply inventories economic outlook market balance risks"
        if args.task == "price" else
        "production policy cut maintain increase quota voluntary adjustment extension phase out meeting guidance"
    )
    with out.open(mode, encoding="utf-8") as handle:
        for position, row in enumerate(test_rows, start=1):
            origin_id = row.get("target_month", row.get("target_date"))
            if origin_id in done:
                continue
            evidence = retrieve(
                available_candidates(docs, args.task, row), query, args.top_k, args.retriever
            )
            record = {
                "origin_id": origin_id, "task": args.task, "target": row["target"],
                "cutoff_date": row["cutoff_date"].isoformat(), "labels": labels,
                "retrieval": evidence, "model": args.model,
                "retriever": args.retriever,
                "protocol_version": PROTOCOL_VERSION,
                "num_ctx": args.num_ctx,
                "thinking_disabled": args.model.startswith("qwen3"),
                "prompt_path": str(PROMPT_PATH.relative_to(REPO_ROOT)),
                "timing_rule": "full origin month before target" if args.task == "price" else "strictly pre-target, 180-day press-release window",
            }
            try:
                if args.dry_run:
                    record["status"] = "retrieval_audited_no_llm_call"
                else:
                    result, audit = call_llm(
                        args.model, instruction, evidence, labels, args.timeout, args.num_ctx
                    )
                    record.update({"status": "complete", "prediction": result, "llm_audit": audit})
            except Exception as exc:  # noqa: BLE001
                record.update({"status": "error", "error": str(exc)})
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")
            handle.flush()
            print(f"{args.task} {position}/{len(test_rows)} {origin_id}: {record['status']}", flush=True)
            time.sleep(0.1)
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
