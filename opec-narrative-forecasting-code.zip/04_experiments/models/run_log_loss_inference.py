#!/usr/bin/env python3
"""Post-hoc paired log-score analysis of frozen, saved probability forecasts.

No model refitting, outcome-based weight selection, or alteration of raw data.
"""
import hashlib
import json
from pathlib import Path
import numpy as np
from sklearn.metrics import log_loss

ROOT = Path(__file__).resolve().parents[2]
SEEDS = [20260917, 20260918, 20260919, 20260920, 20260921]
LABELS = {'price': ['down', 'neutral', 'up'], 'production': ['cut', 'maintain', 'increase']}

def swap(delta, length, draws, seed):
    blocks = np.array([delta[k:k+length].sum() for k in range(0, len(delta), length)])
    rng = np.random.default_rng(seed)
    extreme = 0
    for start in range(0, draws, 5000):
        signs = 2*rng.integers(0, 2, size=(min(5000, draws-start), len(blocks)))-1
        simulated = (signs*blocks).sum(axis=1)/len(delta)
        extreme += int(np.count_nonzero(np.abs(simulated) >= abs(delta.mean())-1e-14))
    return extreme

def interval(delta, length, seed):
    rng = np.random.default_rng(seed)
    starts = rng.integers(0, len(delta), size=(20000, int(np.ceil(len(delta)/length))))
    ix = ((starts[..., None]+np.arange(length)) % len(delta)).reshape(20000, -1)[:, :len(delta)]
    return np.quantile(delta[ix].mean(axis=1), [.025, .975]).tolist()

def holm(p):
    order = np.argsort(p); result = np.empty(len(p)); running = 0.
    for rank, j in enumerate(order):
        running = max(running, (len(p)-rank)*p[j]); result[j] = min(1., running)
    return result.tolist()

def main():
    paths = [ROOT/'04_experiments/models/trend_classification_results.json', ROOT/'05_results/nested_rag_fusion.json']
    trend, fusion = [json.loads(p.read_text()) for p in paths]
    results = []
    for task, labels in LABELS.items():
        rag_path = ROOT/f'04_experiments/models/rag_llm_{task}_llama3.3_70b_tfidf_v2.jsonl'
        paths.append(rag_path)
        rag = [json.loads(x) for x in rag_path.read_text().splitlines() if x.strip()]
        assert all(x['status']=='complete' for x in rag)
        primary = fusion['tasks'][task]['variants']['history_plus_rag_weight_0.50']
        origins = sorted(primary['target_dates']); assert len(set(origins)) == len(origins)
        pred = trend[task+'_trend']['predictions']
        history_name = fusion['tasks'][task]['baseline']
        streams = {}
        for name, block in [('history', pred[history_name]), ('persistence', pred['Persistence']), ('pool', primary)]:
            assert len(set(block['target_dates'])) == len(origins)
            streams[name] = dict(zip(block['target_dates'], zip(block['y_true'], block['probabilities'])))
        streams['RAG'] = {x['origin_id']: (x['target'], [x['prediction']['probabilities'][c] for c in labels]) for x in rag}
        assert all(set(v)==set(origins) for v in streams.values())
        truth = [streams['pool'][o][0] for o in origins]
        y = np.array([labels.index(t) for t in truth]); losses = {}; probabilities = {}
        for name, records in streams.items():
            assert [records[o][0] for o in origins] == truth
            p = np.array([records[o][1] for o in origins], dtype=np.float64)
            assert p.shape==(len(origins), 3) and np.isfinite(p).all() and (p>=0).all() and (p<=1).all()
            assert np.allclose(p.sum(axis=1), 1., atol=1e-8)
            eps = np.finfo(np.float64).eps
            loss = -np.log(np.clip(p[np.arange(len(y)), y], eps, 1-eps))
            assert np.isclose(loss.mean(), log_loss(y, p, labels=[0,1,2]), atol=1e-12)
            losses[name] = loss; probabilities[name] = p
        assert np.allclose(probabilities['pool'], .5*(probabilities['history']+probabilities['RAG']), atol=1e-10)
        assert np.isclose(losses['pool'].mean(), primary['log_loss'], atol=1e-10)
        for candidate, base in [('pool','history'), ('pool','persistence'), ('RAG','persistence')]:
            delta = losses[candidate]-losses[base]
            counts = [swap(delta, 1, 100000, seed) for seed in SEEDS]
            result = {'task':task,'candidate':candidate,'comparator':base,'history_model':history_name,'n':len(origins),
                'candidate_log_loss':float(losses[candidate].mean()),'comparator_log_loss':float(losses[base].mean()),
                'mean_loss_difference':float(delta.mean()),'iid_p':float((sum(counts)+1)/500001),
                'iid_p_by_seed':[(v+1)/100001 for v in counts],
                'block':{str(b):{'ci95':interval(delta,b,SEEDS[0]+b),'p':(swap(delta,b,50000,SEEDS[0]+100*b)+1)/50001} for b in [3,6,12]},
                'paired_records':[{'origin':o,'target':t,'candidate_loss':float(a),'comparator_loss':float(b),'loss_difference':float(a-b)} for o,t,a,b in zip(origins,truth,losses[candidate],losses[base])]}
            results.append(result)
    for rec,p in zip(results,holm([r['iid_p'] for r in results])):rec['iid_holm_p']=p
    for length in ['3','6','12']:
        for rec,p in zip(results,holm([r['block'][length]['p'] for r in results])):rec['block'][length]['holm_p']=p
    out={'analysis_status':'post-hoc secondary analysis, specified after inspecting aggregate log losses',
         'estimand':'mean candidate minus comparator log loss (natural-log units per origin); negative favours candidate',
         'probability_clipping_epsilon':np.finfo(np.float64).eps,'seeds':SEEDS,'iid_draws_per_seed':100000,
         'block_swap_draws':50000,'circular_bootstrap_draws':20000,'holm_family':'all six contrasts jointly; separate adjustment for iid and each block length',
         'assumptions':'paired forecast-assignment exchangeability (blockwise for blocks); mean equality alone is insufficient; dependence/stationarity are not established',
         'scope':'saved retrospective probabilities; no economic cost matrix, portfolio, transaction costs or realised utility evaluated',
         'input_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'comparisons':results}
    (ROOT/'05_results/log_loss_paired_inference.json').write_text(json.dumps(out,indent=2)+'\n')
    for r in results:
        print(r['task'],r['candidate'],r['comparator'], 'losses',round(r['candidate_log_loss'],6),round(r['comparator_log_loss'],6),'delta',round(r['mean_loss_difference'],6),'iid',round(r['iid_p'],6),'Holm',round(r['iid_holm_p'],6),'block6',r['block']['6'])

if __name__=='__main__':main()
