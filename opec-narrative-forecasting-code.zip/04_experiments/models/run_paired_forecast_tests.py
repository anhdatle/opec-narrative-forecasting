#!/usr/bin/env python3
"""Paired randomization tests for every model versus persistence.

The forecast origin is the pairing unit. Under the sharp null that the two
classifiers are exchangeable at each origin, the script independently swaps
their predictions and recomputes the Macro-F1 difference. The test is
exploratory because serial dependence between forecast origins is not modeled.
Monte Carlo stability is checked across five random-number seeds, and Holm
adjustment controls family-wise error within each task.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from sklearn.metrics import f1_score
from scipy.stats import binomtest

ROOT = Path(__file__).resolve().parents[2]
TREND = ROOT / "04_experiments/models/trend_classification_results.json"
OUT = ROOT / "05_results/paired_forecast_randomization_tests.json"
RAG_PATHS = {
    "price": ROOT / "04_experiments/models/rag_llm_price_llama3.3_70b_tfidf_v2.jsonl",
    "production": ROOT / "04_experiments/models/rag_llm_production_llama3.3_70b_tfidf_v2.jsonl",
}
TASK_KEYS = {"price": "price_trend", "production": "production_trend"}
LABELS = {"price": ["down", "neutral", "up"], "production": ["cut", "maintain", "increase"]}


def macro_f1(y_true: list[str], y_pred: list[str], labels: list[str]) -> float:
    return float(f1_score(y_true, y_pred, labels=labels, average="macro", zero_division=0))


MC_SEEDS = [20260823, 20260831, 20260907, 20260919, 20260929]


def vectorized_macro_f1(y: np.ndarray, pred: np.ndarray, n_labels: int) -> np.ndarray:
    scores = np.zeros(pred.shape[0], dtype=float)
    for cls in range(n_labels):
        truth = y == cls
        chosen = pred == cls
        tp = np.sum(chosen & truth, axis=1)
        fp = np.sum(chosen & ~truth, axis=1)
        fn = np.sum(~chosen & truth, axis=1)
        denominator = 2 * tp + fp + fn
        scores += np.divide(2 * tp, denominator, out=np.zeros_like(tp, dtype=float), where=denominator != 0)
    return scores / n_labels


def randomized_p_values(y_true, candidate, baseline, labels, permutations_per_seed=100_000):
    y = np.asarray([labels.index(v) for v in y_true], dtype=np.int8)
    a = np.asarray([labels.index(v) for v in candidate], dtype=np.int8)
    b = np.asarray([labels.index(v) for v in baseline], dtype=np.int8)
    observed = macro_f1(y_true, candidate, labels) - macro_f1(y_true, baseline, labels)
    p_values = []
    total_extreme = 0
    total = 0
    for seed in MC_SEEDS:
        rng = np.random.default_rng(seed)
        extreme = 0
        done = 0
        while done < permutations_per_seed:
            batch = min(5000, permutations_per_seed - done)
            swap = rng.integers(0, 2, size=(batch, len(y)), dtype=np.int8).astype(bool)
            perm_a = np.where(swap, b, a)
            perm_b = np.where(swap, a, b)
            delta = vectorized_macro_f1(y[None, :], perm_a, len(labels)) - vectorized_macro_f1(y[None, :], perm_b, len(labels))
            extreme += int(np.sum(np.abs(delta) >= abs(observed) - 1e-15))
            done += batch
        p = (extreme + 1) / (permutations_per_seed + 1)
        p_values.append(p)
        total_extreme += extreme
        total += permutations_per_seed
    pooled = (total_extreme + 1) / (total + 1)
    return observed, pooled, p_values


def mcnemar_exact(y_true, candidate, baseline):
    candidate_correct = np.asarray(candidate) == np.asarray(y_true)
    baseline_correct = np.asarray(baseline) == np.asarray(y_true)
    candidate_only = int(np.sum(candidate_correct & ~baseline_correct))
    baseline_only = int(np.sum(~candidate_correct & baseline_correct))
    discordant = candidate_only + baseline_only
    p = 1.0 if discordant == 0 else float(binomtest(candidate_only, discordant, 0.5).pvalue)
    return {"candidate_only_correct": candidate_only, "persistence_only_correct": baseline_only,
            "discordant_pairs": discordant, "two_sided_p_value": p}


def holm_adjust(p_values: dict[str, float]) -> dict[str, float]:
    ordered = sorted(p_values, key=p_values.get)
    adjusted = {}
    running = 0.0
    m = len(ordered)
    for rank, name in enumerate(ordered):
        value = min(1.0, (m - rank) * p_values[name])
        running = max(running, value)
        adjusted[name] = running
    return adjusted


def evaluate_task(task: str, permutations_per_seed: int = 100_000) -> dict:
    trend = json.loads(TREND.read_text(encoding="utf-8"))
    baseline = trend[TASK_KEYS[task]]["predictions"]["Persistence"]
    baseline_by_origin = {
        origin: (truth, pred)
        for origin, truth, pred in zip(
            baseline["target_dates"], baseline["y_true"], baseline["y_pred"]
        )
    }
    rag_rows = [
        json.loads(line)
        for line in RAG_PATHS[task].read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if any(row.get("status") != "complete" for row in rag_rows):
        raise RuntimeError(f"{task} RAG run contains incomplete records")
    origins = [row["origin_id"] for row in rag_rows]
    if set(origins) != set(baseline_by_origin):
        raise RuntimeError(f"{task} origins do not align between RAG and persistence")
    y_true = [row["target"] for row in rag_rows]
    rag_pred = [row["prediction"]["forecast_label"] for row in rag_rows]
    persistence_pred = []
    for row in rag_rows:
        truth, pred = baseline_by_origin[row["origin_id"]]
        if truth != row["target"]:
            raise RuntimeError(f"Target mismatch at {row['origin_id']}")
        persistence_pred.append(pred)

    labels = LABELS[task]
    candidates = {
        name: values["y_pred"]
        for name, values in trend[TASK_KEYS[task]]["predictions"].items()
        if name != "Persistence"
    }
    candidates["Pure RAG-LLM raw official text"] = rag_pred
    comparisons = {}
    raw_p = {}
    for name, predictions in candidates.items():
        observed, pooled_p, seed_p = randomized_p_values(
            y_true, predictions, persistence_pred, labels, permutations_per_seed
        )
        raw_p[name] = pooled_p
        comparisons[name] = {
            "candidate_macro_f1": macro_f1(y_true, predictions, labels),
            "persistence_macro_f1": macro_f1(y_true, persistence_pred, labels),
            "observed_macro_f1_difference": observed,
            "two_sided_p_value_pooled": pooled_p,
            "two_sided_p_value_by_mc_seed": dict(zip(map(str, MC_SEEDS), seed_p)),
            "mc_p_value_range": [min(seed_p), max(seed_p)],
            "mcnemar_accuracy_test": mcnemar_exact(y_true, predictions, persistence_pred),
        }
    adjusted = holm_adjust(raw_p)
    for name, value in adjusted.items():
        comparisons[name]["holm_adjusted_p_value_within_task"] = value
    return {
        "task": task,
        "pairing_unit": "forecast origin",
        "n_pairs": len(y_true),
        "comparisons": comparisons,
        "permutations_per_seed": permutations_per_seed,
        "total_permutations_per_comparison": permutations_per_seed * len(MC_SEEDS),
        "monte_carlo_seeds": MC_SEEDS,
        "assumption": "classifier predictions are exchangeable within each origin under the sharp null",
        "limit": "exploratory; does not model serial dependence across forecast origins",
    }


def main() -> None:
    result = {
        "method": "paired label-swap randomization test on Macro-F1 difference; exact McNemar test on accuracy",
        "multiplicity": "Holm family-wise adjustment across candidate-versus-persistence comparisons within each task",
        "tasks": {task: evaluate_task(task) for task in ["price", "production"]},
    }
    OUT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
