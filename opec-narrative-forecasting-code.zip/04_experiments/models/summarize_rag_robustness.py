#!/usr/bin/env python3
"""Evaluate the pre-specified LLM and retriever robustness configurations."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from run_trend_classification import DECISION_LABELS, LABELS, bootstrap_interval, metrics

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "05_results/rag_model_retriever_robustness.json"
CONFIGS = [
    ("llama3.3:70b", "tfidf", "primary"),
    ("llama3.3:70b", "bm25", "retriever_sensitivity"),
    ("qwen3:32b", "tfidf", "model_sensitivity"),
]


def tag(model: str) -> str:
    import re
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", model)


def evaluate(path: Path) -> dict:
    rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    if not rows or any(row.get("status") != "complete" for row in rows):
        raise RuntimeError(f"Incomplete robustness run: {path}")
    labels = LABELS if rows[0]["task"] == "price" else DECISION_LABELS
    y_true = [row["target"] for row in rows]
    y_pred = [row["prediction"]["forecast_label"] for row in rows]
    probability = np.asarray([
        [row["prediction"]["probabilities"][label] for label in labels] for row in rows
    ], dtype=float)
    result = metrics(y_true, y_pred, probability, labels)
    result["macro_f1_ci95_iid_bootstrap"] = bootstrap_interval(
        y_true, y_pred, probability, labels, "macro_f1"
    )
    result["n_oos"] = len(rows)
    return result


def main() -> None:
    result = {
        "purpose": "pre-specified robustness to one alternative lexical retriever and one alternative open-weight LLM",
        "selection_rule": "primary configuration fixed before inspecting v2 OOS scores",
        "tasks": {},
    }
    for task in ("price", "production"):
        task_result = {}
        for model, retriever, role in CONFIGS:
            path = ROOT / f"04_experiments/models/rag_llm_{task}_{tag(model)}_{retriever}_v2.jsonl"
            task_result[f"{model}|{retriever}"] = {
                "role": role,
                "path": str(path.relative_to(ROOT)),
                "metrics": evaluate(path),
            }
        result["tasks"][task] = task_result
    OUT.write_text(json.dumps(result, indent=2) + "\n")
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
