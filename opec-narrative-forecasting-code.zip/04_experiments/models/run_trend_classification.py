#!/usr/bin/env python3
"""Leakage-controlled trend-classification evaluation for the OPEC corpus.

This script replaces the earlier point-return forecast evaluation.  It creates
two strictly temporal classification tasks:

1. Monthly WTI direction (down/neutral/up), 2018--2026.  A document assigned
   to month t is only used for the price target in month t+1.  This full-month
   lag is deliberately conservative because MOMR metadata identify a month,
   not an intraday publication time.
2. Next OPEC production-decision direction (cut/maintain/increase),
   2002--2026. Features for decision i contain only press releases in the
   preceding 180 calendar days; the target-day decision document is excluded.

All scores are expanding-window out-of-sample predictions.  The neural MLP is
an explicitly exploratory capacity-controlled baseline: the available sample
does not support a confirmatory deep-learning claim.
"""
from __future__ import annotations

import calendar
import csv
import json
import os
import re
from collections import defaultdict
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (balanced_accuracy_score, confusion_matrix,
                             f1_score, log_loss, matthews_corrcoef)
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

REPO_ROOT = Path(__file__).resolve().parents[2]
OUT_DIR = Path(__file__).resolve().parent
FIG_DIR = REPO_ROOT / "06_writing/journal_submission/figures"
LABELS = ["down", "neutral", "up"]
DECISION_LABELS = ["cut", "maintain", "increase"]
MONTHS = {m: i for i, m in enumerate(calendar.month_name) if m}
MONTH_ALIASES = {m.lower(): i for i, m in enumerate(calendar.month_name) if m}
MONTH_ALIASES.update({m.lower(): i for i, m in enumerate(calendar.month_abbr) if m})


def month_key(year: int, month: int) -> str:
    return f"{year:04d}-{month:02d}"


def parse_press_date(value: str):
    match = re.fullmatch(r"(\d{1,2})-([A-Za-z]+)-(\d{4})", value or "")
    if not match:
        return None
    day, name, year = match.groups()
    mon = MONTH_ALIASES.get(name.lower().rstrip("."))
    if not mon:
        return None
    from datetime import date, timedelta
    return date(int(year), mon, int(day))


def load_manifest_and_oni():
    manifest = {
        row["doc_id"]: row
        for row in map(json.loads, (REPO_ROOT / "03_data/manifest/document_index.jsonl").read_text().splitlines())
    }
    oni = {
        row["doc_id"]: row["ONI_pca"]
        for row in map(json.loads, (REPO_ROOT / "03_data/derived/annotations/llama3.3_70b_annotations_oni_pca.jsonl").read_text().splitlines())
    }
    return manifest, oni


def load_wti_daily():
    values = []
    snapshot = Path(os.environ.get("OPEC_WTI_CSV", str(REPO_ROOT / "03_data/raw/eia/wti_spot_daily_pulled20260724.csv")))
    with snapshot.open() as handle:
        for row in csv.DictReader(handle):
            if row.get("value"):
                from datetime import date
                values.append((date.fromisoformat(row["period"]), float(row["value"])))
    return sorted(values)


def price_label(log_return: float, threshold: float = 0.02) -> str:
    if log_return < -threshold:
        return "down"
    if log_return > threshold:
        return "up"
    return "neutral"


def build_price_task(threshold: float = 0.02, adaptive_multiplier: float | None = None):
    """Monthly data; t-1 narrative is used to classify WTI movement in t."""
    manifest, oni = load_manifest_and_oni()
    document_scores = defaultdict(list)
    for doc_id, score in oni.items():
        record = manifest.get(doc_id, {})
        if record.get("source_type") == "momr_chapter":
            match = re.match(r"([A-Za-z]+)\s+(\d{4})", record.get("period_label", ""))
            if not match:
                continue
            name, year = match.groups()
            mon = MONTHS.get(name.capitalize())
            if mon:
                document_scores[month_key(int(year), mon)].append(score)
        elif record.get("source_type") == "press_release":
            date = parse_press_date(record.get("meeting_date"))
            if date:
                document_scores[month_key(date.year, date.month)].append(score)

    daily = load_wti_daily()
    prices = defaultdict(list)
    for date, value in daily:
        prices[month_key(date.year, date.month)].append(value)
    monthly_price = {m: float(np.mean(v)) for m, v in prices.items()}
    months = sorted(m for m in monthly_price if "2018-01" <= m <= "2026-06")
    returns = {m: np.log(monthly_price[m] / monthly_price[months[i - 1]])
               for i, m in enumerate(months) if i > 0}

    rows = []
    for i, target_month in enumerate(months):
        if i < 4 or target_month not in returns:
            continue
        feature_month = months[i - 1]
        if feature_month not in document_scores:
            continue
        lag_returns = [returns.get(months[i - j]) for j in range(1, 4)]
        if any(value is None for value in lag_returns):
            continue
        scores = document_scores[feature_month]
        if adaptive_multiplier is None:
            target_threshold = threshold
            threshold_rule = f"fixed_{threshold:.4f}"
        else:
            history = [returns[m] for m in months[max(1, i - 12):i] if m in returns]
            if len(history) < 6:
                continue
            target_threshold = adaptive_multiplier * float(np.std(history, ddof=0))
            threshold_rule = f"adaptive_{adaptive_multiplier:.3f}x_trailing12m_vol"
        rows.append({
            "origin_month": feature_month,
            "target_month": target_month,
            "target": price_label(returns[target_month], target_threshold),
            "target_log_return": returns[target_month],
            "neutral_threshold": target_threshold,
            "threshold_rule": threshold_rule,
            "lag_return_1": lag_returns[0],
            "lag_return_3_mean": float(np.mean(lag_returns)),
            "lag_return_3_vol": float(np.std(lag_returns, ddof=0)),
            "oni_pca_lag1": float(np.mean(scores)),
            "oni_doc_count_lag1": len(scores),
        })
    return rows


def build_production_task():
    """Classify decision i using a 180-day public-text window before its date."""
    from datetime import timedelta
    manifest, oni = load_manifest_and_oni()
    releases = []
    for doc_id, score in oni.items():
        record = manifest.get(doc_id, {})
        if record.get("source_type") != "press_release":
            continue
        date = parse_press_date(record.get("meeting_date"))
        if date:
            releases.append((date, score))
    releases.sort()

    daily = load_wti_daily()
    wti_dates = [date for date, _ in daily]
    wti = dict(daily)
    events = json.loads((REPO_ROOT / "04_experiments/annotation/event_calendar.json").read_text())["events"]
    from datetime import date
    events = sorted(events, key=lambda x: x["date"])
    rows = []
    for i in range(1, len(events)):
        previous, target = events[i - 1], events[i]
        prev_date, target_date = date.fromisoformat(previous["date"]), date.fromisoformat(target["date"])
        # Excluding target_date makes the target's own decision language unavailable.
        # A rolling window is required because many consecutive meetings have no
        # intervening press release; it remains strictly pre-target information.
        interval_scores = [score for released, score in releases
                           if target_date - timedelta(days=180) <= released < target_date]
        prior_releases = [(released, score) for released, score in releases if released < target_date]
        latest_release_age = None
        if not interval_scores and prior_releases:
            latest_date, latest_score = prior_releases[-1]
            interval_scores = [latest_score]
            latest_release_age = (target_date - latest_date).days
        elif prior_releases:
            latest_release_age = (target_date - prior_releases[-1][0]).days
        if not interval_scores:
            continue
        eligible = [d for d in wti_dates if d < target_date]
        if len(eligible) < 21:
            continue
        recent = eligible[-21:]
        log_returns = np.diff(np.log([wti[d] for d in recent]))
        rows.append({
            "origin_date": prev_date.isoformat(),
            "target_date": target_date.isoformat(),
            "target": target["decision_type"],
            "target_label_source": target.get("label_source", "legacy_unrecorded"),
            "target_human_validated": bool(target.get("human_validated", False)),
            "previous_decision": previous["decision_type"],
            "previous_delta_q": previous.get("normalized_action_delta_q_mb_d", previous["delta_q_mb_d"]),
            "wti_return_20d": float(np.sum(log_returns)),
            "wti_vol_20d": float(np.std(log_returns, ddof=0)),
            "oni_pca_predecision_180d": float(np.mean(interval_scores)),
            "oni_doc_count_predecision_180d": len(interval_scores),
            "latest_release_age_days": latest_release_age,
            "days_to_target": (target_date - prev_date).days,
        })
    return rows


def one_hot(rows, categorical, numeric):
    values = []
    categories = sorted({row[categorical] for row in rows})
    for row in rows:
        values.append([row[key] for key in numeric] + [float(row[categorical] == c) for c in categories])
    return np.asarray(values, dtype=float)


def aligned_probabilities(model, x, labels):
    raw = model.predict_proba(x.reshape(1, -1))[0]
    aligned = np.full(len(labels), 1e-12)
    for cls, prob in zip(model.classes_, raw):
        aligned[labels.index(cls)] = prob
    return aligned / aligned.sum()


def metrics(y_true, y_pred, probabilities, labels):
    y_idx = np.asarray([labels.index(y) for y in y_true])
    p = np.asarray(probabilities)
    one_hot_targets = np.eye(len(labels))[y_idx]
    confidence = p.max(axis=1)
    probability_pred = np.asarray(labels, dtype=object)[np.argmax(p, axis=1)]
    correct = probability_pred == np.asarray(y_true)
    bins = np.linspace(0, 1, 11)
    ece = 0.0
    for left, right in zip(bins[:-1], bins[1:]):
        mask = (confidence >= left) & ((confidence < right) if right < 1 else (confidence <= right))
        if mask.any():
            ece += mask.mean() * abs(correct[mask].mean() - confidence[mask].mean())
    # sklearn's log_loss orders string classes lexicographically even when a
    # custom label list is supplied. Reorder probability columns explicitly so
    # production labels (cut, maintain, increase) cannot be mismatched.
    logloss_labels = sorted(labels)
    logloss_probs = p[:, [labels.index(label) for label in logloss_labels]]
    return {
        "macro_f1": float(f1_score(y_true, y_pred, labels=labels, average="macro", zero_division=0)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "mcc": float(matthews_corrcoef(y_true, y_pred)),
        "log_loss": float(log_loss(y_true, logloss_probs, labels=logloss_labels)),
        "multiclass_brier": float(np.mean(np.sum((p - one_hot_targets) ** 2, axis=1)) / len(labels)),
        "ece_10bin": float(ece),
    }


def bootstrap_interval(y_true, y_pred, probabilities, labels, metric, seed=20260812, resamples=2000):
    rng = np.random.default_rng(seed)
    n = len(y_true)
    scores = []
    for _ in range(resamples):
        idx = rng.integers(0, n, n)
        s = metrics([y_true[i] for i in idx], [y_pred[i] for i in idx], np.asarray(probabilities)[idx], labels)[metric]
        scores.append(s)
    return [float(x) for x in np.quantile(scores, [0.025, 0.975])]


def calibrated_persistence_probabilities(rows, y, labels, persistence_feature, origin_index):
    """Training-only probability calibration for a hard persistence forecast.

    The class forecast still repeats the most recently observed class. Its
    confidence is estimated from earlier persistence forecasts with a Beta(1,1)
    correction; the remaining mass is distributed uniformly across the other
    classes. This avoids the mechanically infinite loss
    of assigning probability one to every hard persistence prediction.
    """
    predicted = rows[origin_index][persistence_feature]
    prior = [
        (rows[j][persistence_feature], y[j])
        for j in range(1, origin_index)
        if rows[j][persistence_feature] in labels
    ]
    matched = [(p, truth) for p, truth in prior if p == predicted]
    correct = sum(truth == predicted for _, truth in matched)
    confidence = (correct + 1.0) / (len(matched) + 2.0)
    confidence = min(0.99, max(1.0 / len(labels) + 1e-6, confidence))
    other_labels = [label for label in labels if label != predicted]
    probability = np.zeros(len(labels), dtype=float)
    probability[labels.index(predicted)] = confidence
    for label in other_labels:
        probability[labels.index(label)] = (1.0 - confidence) / len(other_labels)
    return probability / probability.sum()


def evaluate(rows, labels, market_features, oni_features, persistence_feature, min_train,
             price_only_numeric=None, bootstrap_resamples=2000):
    x_market = one_hot(rows, market_features.get("categorical"), market_features["numeric"]) if market_features.get("categorical") else np.asarray([[r[k] for k in market_features["numeric"]] for r in rows], dtype=float)
    x_price_only = (np.asarray([[r[k] for k in price_only_numeric] for r in rows], dtype=float)
                    if price_only_numeric else x_market)
    x_full = np.column_stack([x_market, np.asarray([[r[k] for k in oni_features] for r in rows], dtype=float)])
    y = [r["target"] for r in rows]
    configs = {
        "Persistence": None,
        "Econometric price-history-only": (LogisticRegression(C=0.5, class_weight="balanced", max_iter=5000), x_price_only),
    }
    # These models observe only lagged WTI movement/volatility.  In the price
    # task x_price_only equals x_market; in the production task it explicitly
    # excludes prior decisions, realised quota changes, document counts, and ONI.
    if price_only_numeric:
        configs.update({
            "ML random forest price-history-only": (RandomForestClassifier(n_estimators=500, min_samples_leaf=4, max_features="sqrt", class_weight="balanced", random_state=20260812), x_price_only),
            "DL MLP price-history-only (exploratory)": (make_pipeline(StandardScaler(), MLPClassifier(hidden_layer_sizes=(8,), alpha=3.0, max_iter=3000, early_stopping=False, random_state=20260812)), x_price_only),
        })
    if market_features.get("categorical") or price_only_numeric != market_features["numeric"]:
        configs["Econometric structured-history"] = (LogisticRegression(C=0.5, class_weight="balanced", max_iter=5000), x_market)
    configs.update({
        "Econometric + ONI": (LogisticRegression(C=0.5, class_weight="balanced", max_iter=5000), x_full),
        "ML random forest + ONI": (RandomForestClassifier(n_estimators=500, min_samples_leaf=4, max_features="sqrt", class_weight="balanced", random_state=20260812), x_full),
        "DL MLP + ONI (exploratory)": (make_pipeline(StandardScaler(), MLPClassifier(hidden_layer_sizes=(8,), alpha=3.0, max_iter=3000, early_stopping=False, random_state=20260812)), x_full),
    })
    outputs = {name: {"y_true": [], "y_pred": [], "probabilities": [], "target_dates": []} for name in configs}
    for i in range(min_train, len(rows)):
        for name, config in configs.items():
            target = y[i]
            if config is None:
                pred = rows[i][persistence_feature]
                prob = calibrated_persistence_probabilities(
                    rows, y, labels, persistence_feature, i
                )
            else:
                estimator, x = config
                # A new estimator each origin prevents any state carrying future labels.
                model = estimator
                if hasattr(model, "get_params"):
                    from sklearn.base import clone
                    model = clone(model)
                model.fit(x[:i], y[:i])
                pred = model.predict(x[i:i + 1])[0]
                # Pipeline exposes classes_ after fit, so align its probability vector directly.
                raw = model.predict_proba(x[i:i + 1])[0]
                classes = model.classes_ if hasattr(model, "classes_") else model[-1].classes_
                prob = np.full(len(labels), 1e-12)
                for cls, value in zip(classes, raw):
                    prob[labels.index(cls)] = value
                prob = prob / prob.sum()
            output = outputs[name]
            output["y_true"].append(target)
            output["y_pred"].append(pred)
            output["probabilities"].append(prob.tolist())
            output["target_dates"].append(rows[i].get("target_month", rows[i].get("target_date")))
    summary = {}
    for name, out in outputs.items():
        values = metrics(out["y_true"], out["y_pred"], out["probabilities"], labels)
        values["macro_f1_ci95_iid_bootstrap"] = bootstrap_interval(
            out["y_true"], out["y_pred"], out["probabilities"], labels,
            "macro_f1", resamples=bootstrap_resamples
        )
        values["n_oos"] = len(out["y_true"])
        values["confusion_matrix"] = confusion_matrix(out["y_true"], out["y_pred"], labels=labels).tolist()
        summary[name] = values
    return summary, outputs


def plot_results(price_summary, production_summary):
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    for filename, summary, title in [
        ("trend_classification_performance.pdf", price_summary, "WTI monthly trend: expanding-window out-of-sample"),
        ("production_trend_classification_performance.pdf", production_summary, "OPEC next-decision trend: expanding-window out-of-sample"),
    ]:
        names = list(summary)
        f1 = [summary[n]["macro_f1"] for n in names]
        bal = [summary[n]["balanced_accuracy"] for n in names]
        fig, ax = plt.subplots(figsize=(10, 4.8))
        pos = np.arange(len(names))
        ax.bar(pos - .18, f1, .36, label="Macro-F1", color="#2b6cb0")
        ax.bar(pos + .18, bal, .36, label="Balanced accuracy", color="#d97706")
        ax.set_xticks(pos, names, rotation=22, ha="right")
        ax.set_ylim(0, 1)
        ax.set_ylabel("Out-of-sample score")
        ax.set_title(title)
        ax.legend(frameon=False)
        ax.grid(axis="y", alpha=.25)
        fig.tight_layout()
        fig.savefig(FIG_DIR / filename, bbox_inches="tight")
        plt.close(fig)

    metrics_to_plot = [("multiclass_brier", "Multiclass Brier (lower is better)"),
                       ("ece_10bin", "10-bin ECE (lower is better)")]
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    for ax, (metric, label) in zip(axes, metrics_to_plot):
        # Probability-quality comparison is restricted to the shared benchmark
        # set because price-only ML/DL are defined only for the WTI task.
        names = [name for name in production_summary if name in price_summary]
        pos = np.arange(len(names))
        ax.bar(pos - .18, [price_summary[n][metric] for n in names], .36, label="WTI trend", color="#2b6cb0")
        ax.bar(pos + .18, [production_summary[n][metric] for n in names], .36, label="Production trend", color="#d97706")
        short = {
            "Persistence": "Persistence",
            "Econometric price-history-only": "Logit\nprice",
            "ML random forest price-history-only": "RF\nprice",
            "DL MLP price-history-only (exploratory)": "MLP\nprice",
            "Econometric structured-history": "Logit\nstructured",
            "Econometric + ONI": "Logit\n+ ONI",
            "ML random forest + ONI": "RF\n+ ONI",
            "DL MLP + ONI (exploratory)": "MLP\n+ ONI",
        }
        ax.set_xticks(pos, [short[name] for name in names], rotation=20, ha="right")
        ax.set_ylabel(label)
        ax.grid(axis="y", alpha=.25)
    axes[0].legend(frameon=False)
    fig.suptitle("Probability quality on expanding-window out-of-sample predictions", y=1.02)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "trend_classification_calibration.pdf", bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(11, 3.1))
    ax.axis("off")
    boxes = [
        (0.02, "Official OPEC text\n1,790 documents"),
        (0.26, "Timing gate\nfull-month lag /\npre-target window"),
        (0.50, "Three-class targets\nWTI: down-neutral-up\nDecision: cut-maintain-increase"),
        (0.76, "Expanding-window OOS\nEconometric, ML,\nexploratory MLP"),
    ]
    for x, text in boxes:
        ax.text(x, .5, text, transform=ax.transAxes, ha="center", va="center", fontsize=10,
                bbox=dict(boxstyle="round,pad=.7", fc="#edf2f7", ec="#2b6cb0", lw=1.2))
    for x in [.14, .38, .64]:
        ax.annotate("", xy=(x + .09, .5), xytext=(x, .5), xycoords="axes fraction",
                    arrowprops=dict(arrowstyle="->", lw=1.4, color="#4a5568"))
    ax.text(.5, .1, "Target-day decision documents are excluded; no random cross-validation or point-return metrics.",
            transform=ax.transAxes, ha="center", fontsize=9, color="#4a5568")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "classification_methodology_pipeline.pdf", bbox_inches="tight")
    plt.close(fig)


def main():
    price_rows = build_price_task()
    production_rows = build_production_task()
    if len(price_rows) < 60 or len(production_rows) < 70:
        raise RuntimeError(f"Insufficient origins: price={len(price_rows)}, production={len(production_rows)}")
    # For price persistence, substitute prior observed trend rather than target leakage.
    for i, row in enumerate(price_rows):
        row["previous_trend"] = price_rows[max(0, i - 1)]["target"]
    price_summary, price_predictions = evaluate(
        price_rows, LABELS,
        {"numeric": ["lag_return_1", "lag_return_3_mean", "lag_return_3_vol"]},
        ["oni_pca_lag1", "oni_doc_count_lag1"], "previous_trend", 48,
        price_only_numeric=["lag_return_1", "lag_return_3_mean", "lag_return_3_vol"],
    )
    production_summary, production_predictions = evaluate(
        production_rows, DECISION_LABELS,
        {"numeric": ["previous_delta_q", "wti_return_20d", "wti_vol_20d", "days_to_target", "latest_release_age_days"], "categorical": "previous_decision"},
        ["oni_pca_predecision_180d", "oni_doc_count_predecision_180d"], "previous_decision", 45,
        price_only_numeric=["wti_return_20d", "wti_vol_20d"],
    )
    out = {
        "protocol": {
            "price_target": "WTI monthly log-return direction with fixed 2% neutral band",
            "price_timing": "documents assigned to month t are lagged one full calendar month before target t+1",
            "production_target": "next retained net-new policy action: cut, maintain, or increase; extensions/reaffirmations are maintain",
            "production_label_status": "LLM-extracted event labels with recorded machine adjudications; independent human validation pending",
            "production_timing": "only press releases in the 180 calendar days before the target decision; target-day documents excluded",
            "evaluation": "expanding-window out-of-sample; no random cross-validation",
            "persistence_probabilities": "training-only calibrated confidence with Beta(1,1) correction and uniform allocation of residual mass",
            "dl_status": "exploratory capacity-controlled MLP only; small samples do not support a confirmatory DL claim",
        },
        "sample": {"price_origins": len(price_rows), "production_origins": len(production_rows)},
        "price_trend": {"summary": price_summary, "predictions": price_predictions, "rows": price_rows},
        "production_trend": {"summary": production_summary, "predictions": production_predictions, "rows": production_rows},
    }
    out_path = OUT_DIR / "trend_classification_results.json"
    out_path.write_text(json.dumps(out, indent=2))
    plot_results(price_summary, production_summary)
    print(json.dumps({"sample": out["sample"], "price": price_summary, "production": production_summary}, indent=2))
    print(f"Wrote {out_path}")


if __name__ == "__main__":
    main()
