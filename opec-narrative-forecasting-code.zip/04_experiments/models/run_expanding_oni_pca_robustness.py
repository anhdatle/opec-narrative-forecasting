#!/usr/bin/env python3
"""Re-estimate the ONI PCA representation at every forecast origin.

The primary manuscript uses a first principal component fitted on the complete
document corpus.  This robustness check removes that unsupervised look-ahead:
at each origin, standardisation and PCA loadings are fitted only on documents
available by that origin.  The current eligible documents are then scored with
that origin-specific representation before the conventional models are refit.
"""
from __future__ import annotations

import json
import re
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path

import numpy as np
from sklearn.decomposition import PCA

from run_dependence_aware_tests import block_swap_test
from run_paired_forecast_tests import randomized_p_values
from run_trend_classification import (
    DECISION_LABELS,
    LABELS,
    build_price_task,
    build_production_task,
    evaluate,
    month_key,
    parse_press_date,
)

ROOT = Path(__file__).resolve().parents[2]
ANNOTATIONS = ROOT / "03_data/derived/annotations/llama3.3_70b_annotations.jsonl"
MANIFEST = ROOT / "03_data/manifest/document_index.jsonl"
PRIMARY_RESULTS = ROOT / "04_experiments/models/trend_classification_results.json"
OUTPUT = ROOT / "05_results/expanding_window_oni_pca_robustness.json"
DIRECTION = {"cut": -1.0, "maintain": 0.0, "increase": 1.0}


def load_document_features():
    manifest = {
        row["doc_id"]: row
        for row in map(json.loads, MANIFEST.read_text().splitlines())
    }
    features = {}
    for row in map(json.loads, ANNOTATIONS.read_text().splitlines()):
        features[row["doc_id"]] = np.asarray([
            float(row["sentiment_hawkish"]),
            DIRECTION[row["forward_guidance_direction"]],
            float(row["demand_outlook_tone"]),
            float(row["price_outlook_tone"]),
        ])
    price_month = {}
    release_date = {}
    for doc_id, record in manifest.items():
        if doc_id not in features:
            continue
        if record.get("source_type") == "press_release":
            parsed = parse_press_date(record.get("meeting_date"))
            if parsed:
                release_date[doc_id] = parsed
                price_month[doc_id] = month_key(parsed.year, parsed.month)
        elif record.get("source_type") == "momr_chapter":
            match = re.match(r"([A-Za-z]+)\s+(\d{4})", record.get("period_label", ""))
            if match:
                from run_trend_classification import MONTHS
                month = MONTHS.get(match.group(1).capitalize())
                if month:
                    price_month[doc_id] = month_key(int(match.group(2)), month)
    return features, price_month, release_date


def origin_pca_mean(features, fit_ids, score_ids):
    fit = np.asarray([features[doc_id] for doc_id in fit_ids], dtype=float)
    mean = fit.mean(axis=0)
    sd = fit.std(axis=0, ddof=0)
    sd[sd == 0] = 1.0
    z_fit = (fit - mean) / sd
    pca = PCA(n_components=1).fit(z_fit)
    component = pca.components_[0].copy()
    if component[0] < 0:
        component *= -1.0
    fit_scores = z_fit @ component
    score_sd = fit_scores.std(ddof=0)
    if score_sd == 0:
        score_sd = 1.0
    scored = np.asarray([(features[doc_id] - mean) / sd @ component / score_sd
                         for doc_id in score_ids], dtype=float)
    return float(scored.mean()), {
        "n_fit_documents": len(fit_ids),
        "n_scored_documents": len(score_ids),
        "explained_variance_ratio": float(pca.explained_variance_ratio_[0]),
        "oriented_loadings": component.tolist(),
    }


def expanding_price_rows(features, document_month):
    rows = build_price_task()
    by_month = defaultdict(list)
    for doc_id, value in document_month.items():
        by_month[value].append(doc_id)
    metadata = []
    for row in rows:
        origin = row["origin_month"]
        fit_ids = sorted(doc_id for doc_id, value in document_month.items() if value <= origin)
        score_ids = sorted(by_month[origin])
        value, meta = origin_pca_mean(features, fit_ids, score_ids)
        row["oni_expanding_pca_lag1"] = value
        metadata.append({"origin": origin, **meta})
    for i, row in enumerate(rows):
        row["previous_trend"] = rows[max(0, i - 1)]["target"]
    return rows, metadata


def expanding_policy_rows(features, release_dates):
    rows = build_production_task()
    metadata = []
    for row in rows:
        target = date.fromisoformat(row["target_date"])
        fit_ids = sorted(doc_id for doc_id, released in release_dates.items() if released < target)
        score_ids = sorted(
            doc_id for doc_id, released in release_dates.items()
            if target - timedelta(days=180) <= released < target
        )
        if not score_ids:
            score_ids = [max(fit_ids, key=lambda doc_id: release_dates[doc_id])]
        value, meta = origin_pca_mean(features, fit_ids, score_ids)
        row["oni_expanding_pca_predecision_180d"] = value
        metadata.append({"origin": row["target_date"], **meta})
    return rows, metadata


def selected_metrics(summary):
    keep = [
        "Econometric + ONI",
        "ML random forest + ONI",
        "DL MLP + ONI (exploratory)",
    ]
    return {
        name: {
            key: summary[name][key]
            for key in ("macro_f1", "balanced_accuracy", "mcc", "log_loss",
                        "multiclass_brier", "ece_10bin", "n_oos")
        }
        for name in keep
    }


def paired_logit_inference(candidate, baseline, labels):
    if candidate["target_dates"] != baseline["target_dates"] or candidate["y_true"] != baseline["y_true"]:
        raise RuntimeError("Origin or target mismatch in origin-specific PCA comparison")
    difference, pooled_p, seed_p = randomized_p_values(
        candidate["y_true"], candidate["y_pred"], baseline["y_pred"], labels
    )
    y = np.asarray(candidate["y_true"], dtype=object)
    candidate_pred = np.asarray(candidate["y_pred"], dtype=object)
    baseline_pred = np.asarray(baseline["y_pred"], dtype=object)
    return {
        "macro_f1_difference": difference,
        "iid_label_swap_p": pooled_p,
        "iid_p_range_across_five_mc_seeds": [min(seed_p), max(seed_p)],
        "block_swap_p": {
            str(length): block_swap_test(
                y, candidate_pred, baseline_pred, labels, length,
                draws=100_000, seed=20260824,
            )
            for length in (3, 6, 12)
        },
    }


def main():
    features, document_month, release_dates = load_document_features()
    price_rows, price_metadata = expanding_price_rows(features, document_month)
    policy_rows, policy_metadata = expanding_policy_rows(features, release_dates)

    price_summary, price_predictions = evaluate(
        price_rows, LABELS,
        {"numeric": ["lag_return_1", "lag_return_3_mean", "lag_return_3_vol"]},
        ["oni_expanding_pca_lag1", "oni_doc_count_lag1"],
        "previous_trend", 48,
        price_only_numeric=["lag_return_1", "lag_return_3_mean", "lag_return_3_vol"],
    )
    policy_summary, policy_predictions = evaluate(
        policy_rows, DECISION_LABELS,
        {"numeric": ["previous_delta_q", "wti_return_20d", "wti_vol_20d",
                     "days_to_target", "latest_release_age_days"],
         "categorical": "previous_decision"},
        ["oni_expanding_pca_predecision_180d", "oni_doc_count_predecision_180d"],
        "previous_decision", 45,
        price_only_numeric=["wti_return_20d", "wti_vol_20d"],
    )

    primary = json.loads(PRIMARY_RESULTS.read_text())
    price_global = [row["oni_pca_lag1"] for row in primary["price_trend"]["rows"]]
    policy_global = [row["oni_pca_predecision_180d"] for row in primary["production_trend"]["rows"]]
    output = {
        "protocol": {
            "purpose": "unsupervised representation look-ahead robustness",
            "rule": "standardisation and PCA are re-estimated separately at every origin using only date-eligible documents",
            "price_fit_set": "all MOMR chapters and press releases assigned no later than the completed origin month",
            "policy_fit_set": "all press releases dated strictly before the target decision date",
            "target_labels": "unchanged from the primary experiment",
        },
        "feature_stability": {
            "price_correlation_global_vs_expanding": float(np.corrcoef(
                price_global, [r["oni_expanding_pca_lag1"] for r in price_rows])[0, 1]),
            "policy_correlation_global_vs_expanding": float(np.corrcoef(
                policy_global, [r["oni_expanding_pca_predecision_180d"] for r in policy_rows])[0, 1]),
            "price_explained_variance_range": [
                min(x["explained_variance_ratio"] for x in price_metadata),
                max(x["explained_variance_ratio"] for x in price_metadata),
            ],
            "policy_explained_variance_range": [
                min(x["explained_variance_ratio"] for x in policy_metadata),
                max(x["explained_variance_ratio"] for x in policy_metadata),
            ],
        },
        "primary_full_corpus_pca": {
            "price": selected_metrics(primary["price_trend"]["summary"]),
            "policy": selected_metrics(primary["production_trend"]["summary"]),
        },
        "expanding_origin_pca": {
            "price": selected_metrics(price_summary),
            "policy": selected_metrics(policy_summary),
        },
        "paired_logit_inference": {
            "price_expanding_pca_ONI_vs_price_history": paired_logit_inference(
                price_predictions["Econometric + ONI"],
                primary["price_trend"]["predictions"]["Econometric price-history-only"],
                LABELS,
            ),
            "policy_expanding_pca_ONI_vs_structured_history": paired_logit_inference(
                policy_predictions["Econometric + ONI"],
                primary["production_trend"]["predictions"]["Econometric structured-history"],
                DECISION_LABELS,
            ),
        },
        "origin_metadata": {"price": price_metadata, "policy": policy_metadata},
        "predictions": {
            "price": {name: price_predictions[name] for name in selected_metrics(price_summary)},
            "policy": {name: policy_predictions[name] for name in selected_metrics(policy_summary)},
        },
    }
    OUTPUT.write_text(json.dumps(output, indent=2))
    print(json.dumps({
        "feature_stability": output["feature_stability"],
        "primary_full_corpus_pca": output["primary_full_corpus_pca"],
        "expanding_origin_pca": output["expanding_origin_pca"],
    }, indent=2))
    print(f"Wrote {OUTPUT}")


if __name__ == "__main__":
    main()
