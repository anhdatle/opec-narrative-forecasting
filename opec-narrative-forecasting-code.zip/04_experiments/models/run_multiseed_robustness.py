#!/usr/bin/env python3
"""Algorithmic-seed sensitivity for the stochastic RF and MLP baselines.

Seeds are not treated as additional forecast observations.  Each seed repeats
the complete expanding-window evaluation on the same forecast origins.  The
output therefore describes optimisation/randomisation sensitivity only.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from sklearn.base import clone
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from run_trend_classification import (
    DECISION_LABELS,
    LABELS,
    build_price_task,
    build_production_task,
    metrics,
    one_hot,
)

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "05_results/multiseed_robustness.json"
SEEDS = [101, 211, 307, 401, 503, 601, 701, 809, 907, 1009]


def estimators(seed: int) -> dict:
    return {
        "RF": RandomForestClassifier(
            n_estimators=500,
            min_samples_leaf=4,
            max_features="sqrt",
            class_weight="balanced",
            random_state=seed,
            n_jobs=-1,
        ),
        "MLP": make_pipeline(
            StandardScaler(),
            MLPClassifier(
                hidden_layer_sizes=(8,), alpha=3.0, max_iter=3000,
                early_stopping=False, random_state=seed,
            ),
        ),
    }


def expanding_predictions(rows, labels, x, min_train, estimator):
    y = [row["target"] for row in rows]
    output = {"y_true": [], "y_pred": [], "probabilities": [], "target_dates": []}
    for i in range(min_train, len(rows)):
        model = clone(estimator)
        model.fit(x[:i], y[:i])
        pred = model.predict(x[i:i + 1])[0]
        raw = model.predict_proba(x[i:i + 1])[0]
        classes = model.classes_ if hasattr(model, "classes_") else model[-1].classes_
        probability = np.full(len(labels), 1e-12)
        for cls, value in zip(classes, raw):
            probability[labels.index(cls)] = value
        probability /= probability.sum()
        output["y_true"].append(y[i])
        output["y_pred"].append(pred)
        output["probabilities"].append(probability.tolist())
        output["target_dates"].append(rows[i].get("target_month", rows[i].get("target_date")))
    return output


def task_design(task: str):
    if task == "price":
        rows = build_price_task()
        x_price = np.asarray([
            [r["lag_return_1"], r["lag_return_3_mean"], r["lag_return_3_vol"]]
            for r in rows
        ], dtype=float)
        x_oni = np.column_stack([
            x_price,
            np.asarray([[r["oni_pca_lag1"], r["oni_doc_count_lag1"]] for r in rows], dtype=float),
        ])
        return rows, LABELS, 48, {"price_history_only": x_price, "with_ONI": x_oni}

    rows = build_production_task()
    x_price = np.asarray([
        [r["wti_return_20d"], r["wti_vol_20d"]] for r in rows
    ], dtype=float)
    x_structured = one_hot(
        rows,
        "previous_decision",
        ["previous_delta_q", "wti_return_20d", "wti_vol_20d", "days_to_target", "latest_release_age_days"],
    )
    x_oni = np.column_stack([
        x_structured,
        np.asarray([
            [r["oni_pca_predecision_180d"], r["oni_doc_count_predecision_180d"]]
            for r in rows
        ], dtype=float),
    ])
    return rows, DECISION_LABELS, 45, {"price_history_only": x_price, "with_ONI": x_oni}


def summarize_seed_metrics(records: list[dict]) -> dict:
    keys = ["macro_f1", "balanced_accuracy", "mcc", "log_loss", "multiclass_brier", "ece_10bin"]
    result = {}
    for key in keys:
        values = np.asarray([record["metrics"][key] for record in records], dtype=float)
        result[key] = {
            "mean": float(values.mean()),
            "sample_sd": float(values.std(ddof=1)),
            "min": float(values.min()),
            "max": float(values.max()),
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--task", choices=["price", "production", "both"], default="both")
    args = parser.parse_args()
    selected_tasks = ["price", "production"] if args.task == "both" else [args.task]
    previous = json.loads(OUT.read_text()) if OUT.exists() else {"tasks": {}}
    result = {
        "purpose": "algorithmic-seed sensitivity, not inferential replication",
        "seeds": SEEDS,
        "evaluation": "complete expanding-window refit at every forecast origin",
        "tasks": previous.get("tasks", {}),
    }
    for task in selected_tasks:
        rows, labels, min_train, representations = task_design(task)
        task_result = {"n_oos": len(rows) - min_train, "configurations": {}}
        for representation, x in representations.items():
            for family in ["RF", "MLP"]:
                name = f"{family}_{representation}"
                records = []
                for seed in SEEDS:
                    output = expanding_predictions(rows, labels, x, min_train, estimators(seed)[family])
                    score = metrics(
                        output["y_true"], output["y_pred"], output["probabilities"], labels
                    )
                    records.append({"seed": seed, "metrics": score, "predictions": output})
                task_result["configurations"][name] = {
                    "aggregate": summarize_seed_metrics(records),
                    "runs": records,
                }
                values = [r["metrics"]["macro_f1"] for r in records]
                print(task, name, f"Macro-F1 mean={np.mean(values):.4f}, sd={np.std(values, ddof=1):.4f}")
        result["tasks"][task] = task_result
    OUT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
