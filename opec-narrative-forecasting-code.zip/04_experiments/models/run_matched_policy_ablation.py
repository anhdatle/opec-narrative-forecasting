"""Post-hoc matched-history ablations; preserves all original predictions.

Adds RF/MLP policy-history-only controls, reusing fixed origin-PCA forecasts.
No model selection, target changes, or additional fitting on OOS labels.
"""
import json
from pathlib import Path
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from run_trend_classification import metrics, DECISION_LABELS
from run_paired_forecast_tests import vectorized_macro_f1
from run_log_loss_inference import holm

ROOT=Path(__file__).resolve().parents[2]

def inference(a,b,labels):
    assert a['target_dates']==b['target_dates'] and a['y_true']==b['y_true']
    y=np.array([labels.index(t) for t in a['y_true']])
    pa=np.array([labels.index(t) for t in a['y_pred']])
    pb=np.array([labels.index(t) for t in b['y_pred']])
    score=lambda v: vectorized_macro_f1(y,v,len(labels))
    observed=float(score(pa[None,:])[0]-score(pb[None,:])[0]); out={}
    for length in [1,3,6,12]:
        rng=np.random.default_rng(20260917+length); extreme=0; draws=100000 if length==1 else 50000
        for start in range(0,draws,2000):
            s=rng.integers(0,2,(min(2000,draws-start),int(np.ceil(len(y)/length)))).repeat(length,axis=1)[:,:len(y)].astype(bool)
            d=score(np.where(s,pb,pa))-score(np.where(s,pa,pb))
            extreme+=int((np.abs(d)>=abs(observed)-1e-14).sum())
        out[str(length)]={'p':(extreme+1)/(draws+1)}
    rng=np.random.default_rng(20260917); estimates=[]
    for _ in range(10):
        starts=rng.integers(0,len(y),(2000,int(np.ceil(len(y)/6))))
        ix=((starts[:,:,None]+np.arange(6))%len(y)).reshape(2000,-1)[:,:len(y)]
        estimates.extend(vectorized_macro_f1(y[ix],pa[ix],3)-vectorized_macro_f1(y[ix],pb[ix],3))
    return {'delta_f1':observed,'block6_ci':np.quantile(estimates,[.025,.975]).tolist(),'swaps':out}

def main():
    original=json.loads((ROOT/'04_experiments/models/trend_classification_results.json').read_text())
    expanding=json.loads((ROOT/'05_results/expanding_window_oni_pca_robustness.json').read_text())
    rows=original['production_trend']['rows']; labels=DECISION_LABELS
    numeric=['previous_delta_q','wti_return_20d','wti_vol_20d','days_to_target','latest_release_age_days']
    # Fixed task codebook, not categories inferred from future observations.
    x=np.array([[r[k] for k in numeric]+[float(r['previous_decision']==c) for c in sorted(labels)] for r in rows])
    y=[r['target'] for r in rows]; predictions={}; summary={}; comparisons={}
    names={'RF':'ML random forest + ONI','MLP':'DL MLP + ONI (exploratory)'}
    for name in names:
        p={'y_true':[],'y_pred':[],'probabilities':[],'target_dates':[]}
        for i in range(45,len(rows)):
            model=(RandomForestClassifier(n_estimators=500,min_samples_leaf=4,max_features='sqrt',class_weight='balanced',random_state=20260812) if name=='RF' else make_pipeline(StandardScaler(),MLPClassifier(hidden_layer_sizes=(8,),alpha=3.0,max_iter=3000,early_stopping=False,random_state=20260812)))
            model.fit(x[:i],y[:i]); raw=model.predict_proba(x[i:i+1])[0]
            probs=np.full(3,1e-12)
            for cls,v in zip(model.classes_,raw):probs[labels.index(cls)]=v
            probs/=probs.sum()
            p['y_true'].append(y[i]);p['y_pred'].append(str(model.predict(x[i:i+1])[0]));p['probabilities'].append(probs.tolist());p['target_dates'].append(rows[i]['target_date'])
        predictions[name]=p;summary[name]=metrics(p['y_true'],p['y_pred'],p['probabilities'],labels)
        comparisons[name]=inference(expanding['predictions']['policy'][names[name]],p,labels)
    baseline=original['production_trend']['predictions']['Econometric structured-history']
    comparisons['Logit']=inference(expanding['predictions']['policy']['Econometric + ONI'],baseline,labels)
    for length in ['1','3','6','12']:
        for name,p in zip(comparisons,holm([v['swaps'][length]['p'] for v in comparisons.values()])):comparisons[name]['swaps'][length]['holm_p']=p
    result={'status':'post-hoc matched policy-history ablation','seed':20260812,'numeric_history':numeric,'categorical_history':'previous_decision, fixed task codebook','oni':'origin-specific PCA plus document count','n_oos':61,'test_protocol':'100000 iid swaps; 50000 block swaps at 3/6/12; 20000 circular block6 bootstrap; Holm over three policy models separately at each length','predictions':predictions,'summary':summary,'comparisons':comparisons}
    (ROOT/'05_results/matched_policy_history_ablation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'summary':summary,'comparisons':comparisons},indent=2))

if __name__=='__main__':main()
