#!/usr/bin/env python3
"""Evaluate completed, auditable pure RAG-LLM classification forecasts.

The script refuses to present an incomplete run as a full result. It reads only
records written by run_rag_llm_classifier.py, validates label/probability
outputs, calculates the same classification metrics as the ONI baselines, and
writes a compact derived JSON summary.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from run_trend_classification import DECISION_LABELS, LABELS, bootstrap_interval, metrics


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--expected", required=True, type=int, help="Required number of OOS origins")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    records = [json.loads(line) for line in args.input.read_text(encoding="utf-8").splitlines() if line.strip()]
    completed = [row for row in records if row.get("status") == "complete"]
    if len(records) != args.expected or len(completed) != args.expected:
        raise RuntimeError(
            f"Run is incomplete: {len(completed)} completed of {args.expected}; "
            f"{len(records) - len(completed)} records are errors or incomplete."
        )
    if len({row["origin_id"] for row in completed}) != args.expected:
        raise RuntimeError("Duplicate or missing forecast origins.")
    labels = LABELS if completed[0]["task"] == "price" else DECISION_LABELS
    y_true = [row["target"] for row in completed]
    y_pred = [row["prediction"]["forecast_label"] for row in completed]
    probs = []
    for row in completed:
        prediction = row["prediction"]
        if prediction["forecast_label"] not in labels or not set(prediction["evidence_doc_ids"]).issubset(
            {item["doc_id"] for item in row["retrieval"]}
        ):
            raise RuntimeError(f"Invalid forecast evidence or label at {row['origin_id']}")
        vector = [float(prediction["probabilities"][label]) for label in labels]
        if not np.isclose(sum(vector), 1.0, atol=0.011):
            raise RuntimeError(f"Probabilities do not sum to one at {row['origin_id']}")
        probs.append(vector)
    summary = metrics(y_true, y_pred, probs, labels)
    summary["macro_f1_ci95_iid_bootstrap"] = bootstrap_interval(y_true, y_pred, probs, labels, "macro_f1")
    summary.update({
        "model": completed[0]["model"], "task": completed[0]["task"], "n_oos": len(completed),
        "timing_rule": completed[0]["timing_rule"],
        "retrieval_k": len(completed[0]["retrieval"]),
        "retriever": completed[0].get("retriever", "legacy_unrecorded"),
        "protocol_version": completed[0].get("protocol_version", "legacy_v1"),
        "prompt_path": completed[0].get("prompt_path"),
        "all_predictions_auditable": True,
    })
    args.output.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
