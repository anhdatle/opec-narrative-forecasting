#!/usr/bin/env python3
"""Paired tests of the fixed history-plus-RAG pool against matched history."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from run_dependence_aware_tests import block_bootstrap, block_swap_test, macro_f1
from run_paired_forecast_tests import mcnemar_exact, randomized_p_values

ROOT = Path(__file__).resolve().parents[2]
TREND = ROOT / "04_experiments/models/trend_classification_results.json"
FUSION = ROOT / "05_results/nested_rag_fusion.json"
OUT = ROOT / "05_results/nested_incremental_forecast_tests.json"
LABELS = {
    "price": ["down", "neutral", "up"],
    "production": ["cut", "maintain", "increase"],
}


def evaluate(task: str, trend: dict, fusion: dict) -> dict:
    task_key = "price_trend" if task == "price" else "production_trend"
    baseline_name = fusion["tasks"][task]["baseline"]
    baseline = trend[task_key]["predictions"][baseline_name]
    baseline_by_origin = dict(zip(baseline["target_dates"], baseline["y_pred"]))
    primary = fusion["tasks"][task]["variants"]["history_plus_rag_weight_0.50"]
    origins = primary["target_dates"]
    y_true = primary["y_true"]
    candidate = primary["predictions"]
    baseline_predictions = [baseline_by_origin[origin] for origin in origins]
    labels = LABELS[task]
    observed, pooled_p, seed_p = randomized_p_values(
        y_true, candidate, baseline_predictions, labels
    )
    y_array = np.asarray(y_true, dtype=object)
    candidate_array = np.asarray(candidate, dtype=object)
    baseline_array = np.asarray(baseline_predictions, dtype=object)
    return {
        "candidate": "History + RAG fixed 0.50 pool",
        "baseline": baseline_name,
        "n_pairs": len(origins),
        "candidate_macro_f1": macro_f1(y_array, candidate_array, labels),
        "baseline_macro_f1": macro_f1(y_array, baseline_array, labels),
        "observed_macro_f1_difference": observed,
        "iid_origin_label_swap_two_sided_p_pooled": pooled_p,
        "iid_origin_label_swap_p_by_seed": seed_p,
        "mcnemar_accuracy_test": mcnemar_exact(
            y_true, candidate, baseline_predictions
        ),
        "dependence_aware": {
            str(length): {
                "moving_block_bootstrap_ci95": block_bootstrap(
                    y_array, candidate_array, baseline_array, labels, length
                ),
                "block_swap_two_sided_p": block_swap_test(
                    y_array, candidate_array, baseline_array, labels, length
                ),
            }
            for length in (3, 6, 12)
        },
    }


def main() -> None:
    trend = json.loads(TREND.read_text(encoding="utf-8"))
    fusion = json.loads(FUSION.read_text(encoding="utf-8"))
    result = {
        "estimand": "incremental predictive content of raw-text RAG probabilities beyond the matched non-text history model",
        "candidate_policy": "fixed 0.50 convex pool; no OOS weight selection",
        "tasks": {
            task: evaluate(task, trend, fusion)
            for task in ("price", "production")
        },
    }
    OUT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
