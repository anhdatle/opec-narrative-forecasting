#!/usr/bin/env python3
"""Sensitivity of the WTI three-class results to the neutral-band definition."""
from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

import numpy as np
from sklearn.base import clone
from sklearn.linear_model import LogisticRegression

from run_trend_classification import (
    LABELS, build_price_task, calibrated_persistence_probabilities, metrics,
)

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "05_results/price_threshold_sensitivity.json"


def evaluate_rows(rows):
    for index, row in enumerate(rows):
        row["previous_trend"] = rows[max(0, index - 1)]["target"]
    y = [row["target"] for row in rows]
    x_history = np.asarray([[row["lag_return_1"], row["lag_return_3_mean"], row["lag_return_3_vol"]] for row in rows])
    x_oni = np.column_stack([x_history, np.asarray([[row["oni_pca_lag1"], row["oni_doc_count_lag1"]] for row in rows])])
    outputs = {
        "Persistence": {"y_true": [], "y_pred": [], "probabilities": []},
        "Econometric price-history-only": {"y_true": [], "y_pred": [], "probabilities": []},
        "Econometric + ONI": {"y_true": [], "y_pred": [], "probabilities": []},
    }
    estimator = LogisticRegression(C=0.5, class_weight="balanced", max_iter=5000)
    for index in range(48, len(rows)):
        persistence_label = rows[index]["previous_trend"]
        persistence_probability = calibrated_persistence_probabilities(
            rows, y, LABELS, "previous_trend", index
        )
        for name, prediction, probability in [
            ("Persistence", persistence_label, persistence_probability),
        ]:
            outputs[name]["y_true"].append(y[index]); outputs[name]["y_pred"].append(prediction); outputs[name]["probabilities"].append(probability.tolist())
        for name, design in [("Econometric price-history-only", x_history), ("Econometric + ONI", x_oni)]:
            model = clone(estimator).fit(design[:index], y[:index])
            prediction = model.predict(design[index:index+1])[0]
            raw = model.predict_proba(design[index:index+1])[0]
            probability = np.full(len(LABELS), 1e-12)
            for label, value in zip(model.classes_, raw): probability[LABELS.index(label)] = value
            probability /= probability.sum()
            outputs[name]["y_true"].append(y[index]); outputs[name]["y_pred"].append(prediction); outputs[name]["probabilities"].append(probability.tolist())
    summary = {
        name: metrics(values["y_true"], values["y_pred"], values["probabilities"], LABELS)
        for name, values in outputs.items()
    }
    return {
        "n_origins": len(rows),
        "n_oos": len(rows) - 48,
        "oos_class_counts": dict(Counter(row["target"] for row in rows[48:])),
        "summary": summary,
    }


def main() -> None:
    specifications = {}
    for threshold in (0.0, 0.01, 0.02, 0.03):
        specifications[f"fixed_{threshold:.2f}"] = evaluate_rows(build_price_task(threshold=threshold))
    specifications["adaptive_0.5x_trailing12m_vol"] = evaluate_rows(
        build_price_task(adaptive_multiplier=0.5)
    )
    result = {
        "purpose": "target-definition sensitivity; no specification is selected using OOS performance",
        "primary": "fixed_0.02",
        "specifications": specifications,
    }
    OUT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
