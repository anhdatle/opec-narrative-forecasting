#!/usr/bin/env python3
"""Create a row-level timing and leakage audit for all classification inputs.

This audit does not infer unavailable intraday release times. It distinguishes
an official press-release calendar date (validated against the official URL)
from a MOMR reporting-month label, and records the information-set rule used by
each forecasting task and RAG bundle.
"""
from __future__ import annotations

import json
import re
from collections import Counter
from datetime import date
from pathlib import Path

from run_trend_classification import build_price_task, build_production_task, parse_press_date

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "05_results/temporal_provenance_audit.json"
REPORT = ROOT / "05_results/TEMPORAL_PROVENANCE_AUDIT.md"


def main() -> None:
    manifest = [json.loads(line) for line in (ROOT / "03_data/manifest/document_index.jsonl").read_text().splitlines()]
    document_rows = []
    for row in manifest:
        if row["source_type"] == "press_release":
            available = parse_press_date(row["meeting_date"])
            slug = re.search(r"pr-detail/\d+-(\d{1,2}-[a-z]+-\d{4})\.html$", row["source_url"], re.I)
            url_date = parse_press_date(slug.group(1)) if slug else None
            document_rows.append({
                "doc_id": row["doc_id"], "source_type": "press_release",
                "availability_status": "official_calendar_date_only",
                "available_date": available.isoformat() if available else None,
                "official_url_date_matches_manifest": bool(available and url_date == available),
                "intraday_timestamp_available": False,
            })
        else:
            document_rows.append({
                "doc_id": row["doc_id"], "source_type": "momr_chapter",
                "availability_status": "reporting_month_only_not_verified_publication_date",
                "reporting_month_label": row.get("period_label", "").split(" ", 2)[:2],
                "intraday_timestamp_available": False,
            })

    price_rows = build_price_task()
    production_rows = build_production_task()
    price_checks = [{
        "origin_month": row["origin_month"], "target_month": row["target_month"],
        "rule": "all narrative aggregates are assigned to t-1; target is return in t",
        "calendar_lag_months": 1,
        "timestamp_claim": "not made; MOMR uses reporting-month metadata only",
    } for row in price_rows]
    production_checks = [{
        "origin_date": row["origin_date"], "target_date": row["target_date"],
        "rule": "press releases have date strictly earlier than target decision date",
        "target_day_document_excluded": True,
        "latest_release_age_days": row["latest_release_age_days"],
    } for row in production_rows]

    rag_checks = {}
    for task in ["price", "production"]:
        path = ROOT / f"04_experiments/models/rag_llm_{task}_llama3.3_70b_tfidf_v2.jsonl"
        records = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
        violations = []
        type_counts = Counter()
        for record in records:
            cutoff = date.fromisoformat(record["cutoff_date"])
            for evidence in record["retrieval"]:
                available = date.fromisoformat(evidence["available_date"])
                type_counts[evidence["source_type"]] += 1
                allowed = available <= cutoff if task == "price" else available < cutoff
                if not allowed:
                    violations.append({"origin": record["origin_id"], "doc_id": evidence["doc_id"]})
        rag_checks[task] = {
            "n_forecasts": len(records), "retrieved_source_types": dict(type_counts),
            "timing_violations": violations, "all_retrieval_dates_pass_calendar_rule": not violations,
            "important_limit": "MOMR evidence dates are reporting-month proxies, not verified publication timestamps." if task == "price" else "Press-release dates are date-only; intraday ordering remains unobserved.",
        }

    audit = {
        "purpose": "Temporal provenance; not a claim of intraday timestamp recovery.",
        "document_summary": {
            "n_documents": len(document_rows),
            "by_source_and_status": {
                f"{source_type}|{status}": count
                for (source_type, status), count in Counter(
                    (x["source_type"], x["availability_status"]) for x in document_rows
                ).items()
            },
            "press_release_url_date_matches": sum(x.get("official_url_date_matches_manifest", False) for x in document_rows),
            "press_release_n": sum(x["source_type"] == "press_release" for x in document_rows),
        },
        "price_classification": {"n_origins": len(price_checks), "checks": price_checks},
        "production_classification": {"n_origins": len(production_checks), "checks": production_checks},
        "production_target_measurement": {
            "status": "LLM-extracted labels with recorded machine adjudications; independent human validation pending",
            "human_validated_events": sum(row.get("target_human_validated", False) for row in production_rows),
            "machine_adjudicated_targets": sum(row.get("target_label_source") == "machine_adjudicated" for row in production_rows),
        },
        "rag_retrieval": rag_checks,
        "document_rows": document_rows,
    }
    OUT.write_text(json.dumps(audit, indent=2) + "\n")
    REPORT.write_text(
        "# Temporal Provenance and Leakage Audit\n\n"
        f"- Official corpus: {len(document_rows)} documents.\n"
        f"- Press releases: {audit['document_summary']['press_release_url_date_matches']}/{audit['document_summary']['press_release_n']} manifest dates match the date encoded in the official OPEC URL. These are calendar dates, not timestamps.\n"
        "- MOMR chapters: reporting-month labels only; no verified publication day/time is claimed.\n"
        f"- Price task: {len(price_checks)} origins use a one-month calendar lag. This is conservative but does not convert a reporting-month label into a verified release time.\n"
        f"- Production task: {len(production_checks)} origins exclude target-day documents by construction.\n"
        f"- RAG retrieval: price calendar-date violations={len(rag_checks['price']['timing_violations'])}; production calendar-date violations={len(rag_checks['production']['timing_violations'])}.\n\n"
        "## Interpretation\n\n"
        "The audit supports date-level leakage controls. It does not support an intraday announcement-timing or causal-surprise claim. All manuscript language must retain this boundary.\n"
    )
    print(json.dumps({"out": str(OUT), "summary": audit["document_summary"], "rag": rag_checks}, indent=2))


if __name__ == "__main__":
    main()
