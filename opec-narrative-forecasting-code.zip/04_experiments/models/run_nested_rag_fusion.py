#!/usr/bin/env python3
"""Fixed, untuned probability pooling to test incremental raw-text content."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from run_trend_classification import DECISION_LABELS, LABELS, bootstrap_interval, metrics

ROOT = Path(__file__).resolve().parents[2]
TREND = ROOT / "04_experiments/models/trend_classification_results.json"
OUT = ROOT / "05_results/nested_rag_fusion.json"
RAG = {
    "price": ROOT / "04_experiments/models/rag_llm_price_llama3.3_70b_tfidf_v2.jsonl",
    "production": ROOT / "04_experiments/models/rag_llm_production_llama3.3_70b_tfidf_v2.jsonl",
}


def load_jsonl(path: Path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def task_result(task: str, trend: dict) -> dict:
    task_key = "price_trend" if task == "price" else "production_trend"
    baseline_name = "Econometric price-history-only" if task == "price" else "Econometric structured-history"
    labels = LABELS if task == "price" else DECISION_LABELS
    baseline = trend[task_key]["predictions"][baseline_name]
    baseline_by_origin = {
        origin: (truth, np.asarray(probability, dtype=float))
        for origin, truth, probability in zip(
            baseline["target_dates"], baseline["y_true"], baseline["probabilities"]
        )
    }
    rag_rows = load_jsonl(RAG[task])
    if any(row.get("status") != "complete" for row in rag_rows):
        raise RuntimeError(f"Incomplete RAG run for {task}")
    origins = [row["origin_id"] for row in rag_rows]
    if set(origins) != set(baseline_by_origin):
        raise RuntimeError(f"Origin mismatch for {task}")
    y_true = []
    baseline_probabilities = []
    rag_probabilities = []
    for row in rag_rows:
        truth, base_probability = baseline_by_origin[row["origin_id"]]
        if truth != row["target"]:
            raise RuntimeError(f"Target mismatch at {row['origin_id']}")
        y_true.append(truth)
        baseline_probabilities.append(base_probability)
        rag_probabilities.append(np.asarray([
            row["prediction"]["probabilities"][label] for label in labels
        ], dtype=float))
    baseline_probabilities = np.asarray(baseline_probabilities)
    rag_probabilities = np.asarray(rag_probabilities)
    variants = {}
    for text_weight in (0.25, 0.50, 0.75):
        pooled = (1.0 - text_weight) * baseline_probabilities + text_weight * rag_probabilities
        predictions = [labels[index] for index in np.argmax(pooled, axis=1)]
        score = metrics(y_true, predictions, pooled, labels)
        score["macro_f1_ci95_iid_bootstrap"] = bootstrap_interval(
            y_true, predictions, pooled, labels, "macro_f1"
        )
        score.update({
            "text_weight": text_weight,
            "predictions": predictions,
            "probabilities": pooled.tolist(),
            "target_dates": origins,
            "y_true": y_true,
        })
        variants[f"history_plus_rag_weight_{text_weight:.2f}"] = score
    return {
        "baseline": baseline_name,
        "primary_variant": "history_plus_rag_weight_0.50",
        "weight_policy": "0.50 fixed a priori; 0.25 and 0.75 are non-selected sensitivity checks",
        "variants": variants,
    }


def main() -> None:
    trend = json.loads(TREND.read_text(encoding="utf-8"))
    result = {
        "estimand": "incremental predictive content of RAG probabilities when added to a matched non-text probability forecast",
        "method": "fixed convex probability pool; no OOS weight tuning",
        "tasks": {task: task_result(task, trend) for task in ("price", "production")},
    }
    OUT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
