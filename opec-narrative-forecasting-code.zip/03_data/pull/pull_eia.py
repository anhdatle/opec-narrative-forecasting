#!/usr/bin/env python3
"""Pull free EIA daily series: WTI/Brent spot prices and the WTI futures-contract
curve (proxy for futures-curve slope, replacing the proposal's paid Bloomberg/
Refinitiv 1M-12M curve with a free 1M-4M proxy — see DECISIONS.md).

Requires a free EIA API key: https://www.eia.gov/opendata/register.php
Set EIA_API_KEY as an environment variable or in a repo-root .env file.

Usage:
  python 03_data/pull/pull_eia.py
"""
from __future__ import annotations

import sys
from pathlib import Path

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _common import require_api_key, write_csv_dated  # noqa: E402

EIA_BASE = "https://api.eia.gov/v2"

# route, series_id, output base name
SPOT_SERIES = [
    ("petroleum/pri/spt", "RWTC", "wti_spot_daily"),
    ("petroleum/pri/spt", "RBRTE", "brent_spot_daily"),
]
FUTURES_SERIES = [
    ("petroleum/pri/fut", "RCLC1", "wti_futures_contract1"),
    ("petroleum/pri/fut", "RCLC2", "wti_futures_contract2"),
    ("petroleum/pri/fut", "RCLC3", "wti_futures_contract3"),
    ("petroleum/pri/fut", "RCLC4", "wti_futures_contract4"),
]


def fetch_series(route: str, series_id: str, api_key: str) -> list[dict]:
    url = f"{EIA_BASE}/{route}/data/"
    params = {
        "api_key": api_key,
        "frequency": "daily",
        "data[0]": "value",
        "facets[series][]": series_id,
        "sort[0][column]": "period",
        "sort[0][direction]": "asc",
        "length": 5000,
        "offset": 0,
    }
    all_rows: list[dict] = []
    while True:
        resp = requests.get(url, params=params, timeout=30)
        if resp.status_code != 200:
            print(f"ERROR {resp.status_code} for {series_id}: {resp.text[:300]}", file=sys.stderr)
            break
        payload = resp.json()
        rows = payload.get("response", {}).get("data", [])
        if not rows:
            break
        all_rows.extend(rows)
        if len(rows) < params["length"]:
            break
        params["offset"] += params["length"]
    return all_rows


def main() -> int:
    api_key = require_api_key("EIA_API_KEY", "https://www.eia.gov/opendata/register.php")

    for route, series_id, base_name in SPOT_SERIES + FUTURES_SERIES:
        print(f"Fetching {series_id} ({route}) ...")
        rows = fetch_series(route, series_id, api_key)
        if not rows:
            print(f"  no rows returned for {series_id} (check series ID is still valid)")
            continue
        clean = [{"period": r.get("period"), "series": series_id, "value": r.get("value")} for r in rows]
        write_csv_dated("eia", base_name, clean, fieldnames=["period", "series", "value"])

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
