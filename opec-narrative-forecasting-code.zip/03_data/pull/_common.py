"""Shared helpers for market/macro data pull scripts.

All pull scripts write CSVs under 03_data/raw/<source>/ and never overwrite an
existing dated raw file — see write_csv_atomic_versioned.
"""
from __future__ import annotations

import csv
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv

REPO_ROOT = Path(__file__).resolve().parents[2]
RAW_DIR = REPO_ROOT / "03_data" / "raw"

load_dotenv(REPO_ROOT / ".env")


def require_api_key(env_var: str, register_url: str) -> str:
    key = os.environ.get(env_var)
    if not key:
        print(
            f"ERROR: {env_var} not set.\n"
            f"Get a free key at {register_url}\n"
            f"Then either `export {env_var}=...` or add `{env_var}=...` to a "
            f".env file at the repo root (see .env.example).",
            file=sys.stderr,
        )
        sys.exit(1)
    return key


def write_csv_dated(source: str, base_name: str, rows: list[dict], fieldnames: list[str]) -> Path:
    """Write a dated snapshot CSV; never overwrites a prior pull (AGENTS.md: raw data is sacrosanct).

    Path: 03_data/raw/<source>/<base_name>_pulled<YYYYMMDD>.csv
    Re-running the same day is idempotent-safe: if today's file already exists,
    it is left untouched and the path is returned as-is (no silent overwrite).
    """
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d")
    out_dir = RAW_DIR / source
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{base_name}_pulled{stamp}.csv"
    if path.exists():
        print(f"SKIP write (already pulled today, raw data is not overwritten): {path}")
        return path
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {len(rows)} rows -> {path}")
    return path
