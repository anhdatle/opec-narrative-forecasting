#!/usr/bin/env python3
"""Scrape OPEC press releases from opec.org (current site structure, confirmed
2026-07-24). Same headless-Playwright, fresh-context-per-page approach as
scrape_opec_momr.py — see that file's docstring for why.

URL patterns (discovered live, not assumed from the original proposal, which
referenced a now-defunct opec_web/en/press_room/*.htm structure):
  Year index:  https://www.opec.org/press-releases.html          (current year)
               https://www.opec.org/press-releases-<YYYY>.html   (2002-2025; the
               year dropdown does not go earlier than 2002 — proposal wanted
               back to 2000, this is a ~2-year gap, logged in DECISIONS.md)
  Detail page: https://www.opec.org/pr-detail/<id>-<date-slug>.html

Usage:
  python 03_data/scrape/scrape_opec_press_releases.py --limit-years 2   # validation run
  python 03_data/scrape/scrape_opec_press_releases.py                  # full run, all years
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

REPO_ROOT = Path(__file__).resolve().parents[2]
RAW_DIR = REPO_ROOT / "03_data" / "raw" / "opec_press_releases"
MANIFEST_PATH = REPO_ROOT / "03_data" / "manifest" / "document_index.jsonl"

UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
BASE = "https://www.opec.org"
CURRENT_YEAR_URL = f"{BASE}/press-releases.html"
YEAR_URL_TMPL = f"{BASE}/press-releases-{{year}}.html"
EARLIEST_YEAR = 2002  # confirmed live: the year dropdown does not go earlier

PR_DETAIL_RE = re.compile(r"/pr-detail/(\d+)-([a-z0-9-]+)\.html$", re.I)
FOOTER_MARKER = "\nADDRESS\n"
HEADER_END_MARKER = "\nPrint\n"


def fetch(browser, url: str, retries: int = 2, settle_seconds: float = 1.0) -> tuple[int | None, str, list[dict]]:
    """Fetch a URL in a FRESH browser context (rate-limit-safe, see scrape_opec_momr.py)."""
    for attempt in range(1, retries + 2):
        context = browser.new_context(user_agent=UA)
        page = context.new_page()
        try:
            resp = page.goto(url, timeout=30000, wait_until="domcontentloaded")
            time.sleep(settle_seconds)
            status = resp.status if resp else None
            text = page.inner_text("body")
            links = page.evaluate(
                "() => Array.from(document.querySelectorAll('a')).map(a => a.href)"
            )
            return status, text, links
        except Exception as exc:  # noqa: BLE001
            print(f"  attempt {attempt} error on {url}: {exc}", file=sys.stderr)
        finally:
            context.close()
        time.sleep(2 * attempt)
    return None, "", []


VIDEO_TIMER_RE = re.compile(r"^\d{1,2}:\d{2}\s*/\s*\d{1,2}:\d{2}$")


def clean_press_release_text(text: str) -> str:
    if HEADER_END_MARKER in text:
        text = text.split(HEADER_END_MARKER, 1)[1]
    if FOOTER_MARKER in text:
        text = text.split(FOOTER_MARKER, 1)[0]
    # Some releases embed a video player whose "0:00 / 2:12" timer text lands
    # as a stray first line — drop it so it doesn't get picked up as the title.
    lines = [ln for ln in text.splitlines() if not VIDEO_TIMER_RE.match(ln.strip())]
    return "\n".join(lines).strip()


def discover_years() -> list[str]:
    import datetime

    current_year = datetime.datetime.now().year  # informational only; not used for randomness-sensitive logic
    return [str(y) for y in range(EARLIEST_YEAR, current_year + 2)]  # +2 headroom, missing years just 404/skip


def discover_release_links_for_year(browser, year: str) -> list[str]:
    url = CURRENT_YEAR_URL if year == "current" else YEAR_URL_TMPL.format(year=year)
    status, _text, links = fetch(browser, url)
    if status != 200:
        return []
    ids_seen: dict[str, str] = {}
    for href in links:
        m = PR_DETAIL_RE.search(href)
        if m:
            ids_seen[m.group(1)] = href
    return list(ids_seen.values())


def get_existing_manifest_doc_ids() -> set[str]:
    if not MANIFEST_PATH.exists():
        return set()
    ids = set()
    with MANIFEST_PATH.open(encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                try:
                    ids.add(json.loads(line)["doc_id"])
                except (json.JSONDecodeError, KeyError):
                    continue
    return ids


def append_manifest_entry(entry: dict) -> None:
    MANIFEST_PATH.parent.mkdir(parents=True, exist_ok=True)
    with MANIFEST_PATH.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, ensure_ascii=False) + "\n")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--limit-years", type=int, default=None, help="Only process the first N years (most recent first)")
    parser.add_argument("--sleep", type=float, default=1.5)
    args = parser.parse_args()

    years = ["current"] + list(reversed(discover_years()[:-2]))  # current year first, then descending historical
    if args.limit_years:
        years = years[: args.limit_years]

    existing_ids = get_existing_manifest_doc_ids()
    n_ok, n_fail, n_skip = 0, 0, 0

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)

        for year in years:
            print(f"\n=== Year: {year} ===")
            time.sleep(args.sleep)
            release_urls = discover_release_links_for_year(browser, year)
            print(f"  {len(release_urls)} press releases found")

            for url in release_urls:
                m = PR_DETAIL_RE.search(url)
                if not m:
                    continue
                pr_id, slug = m.group(1), m.group(2)
                doc_id = f"pr_{pr_id}"
                if doc_id in existing_ids:
                    n_skip += 1
                    continue

                time.sleep(args.sleep)
                status, raw_text, _links = fetch(browser, url)
                if status != 200 or not raw_text:
                    print(f"  FAIL {doc_id}: status={status}")
                    n_fail += 1
                    continue

                cleaned = clean_press_release_text(raw_text)
                title = cleaned.splitlines()[0].strip() if cleaned else ""

                out_path = RAW_DIR / f"{pr_id}.txt"
                out_path.parent.mkdir(parents=True, exist_ok=True)
                out_path.write_text(cleaned, encoding="utf-8")

                append_manifest_entry(
                    {
                        "doc_id": doc_id,
                        "source_type": "press_release",
                        "meeting_id": None,
                        "meeting_date": slug,
                        "title": title,
                        "pr_id": pr_id,
                        "source_url": url,
                        "local_path": str(out_path.relative_to(REPO_ROOT)),
                    }
                )
                existing_ids.add(doc_id)
                n_ok += 1
                print(f"  OK {doc_id}: {title[:70]} ({len(cleaned)} chars)")

        browser.close()

    print(f"\nDone. ok={n_ok} fail={n_fail} skipped_existing={n_skip}")
    print(f"Manifest: {MANIFEST_PATH}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
