#!/usr/bin/env python3
"""Scrape OPEC Monthly Oil Market Report chapters from publications.opec.org
(the modern HTML portal, covering January 2018 - present; pre-2018 needs a
separate source, see DECISIONS.md).

Why headless Playwright + a fresh browser context per page: plain HTTP clients
(curl/requests) get a flat 403 from Cloudflare on this site regardless of
headers. Headless Chromium passes the JS challenge, BUT re-using one browser
*context* across many sequential navigations gets flagged and blocked ("Sorry,
you have been blocked") after a few requests — confirmed empirically. A fresh
context per page reliably returns 200. This is slower (new context = new
challenge-solve) but far more reliable; a small delay between requests is
added to be a considerate scraper on top of that.

Usage:
  python 03_data/scrape/scrape_opec_momr.py --limit-months 2   # small validation run
  python 03_data/scrape/scrape_opec_momr.py                    # full run (all discovered months)
  python 03_data/scrape/scrape_opec_momr.py --discover-only    # just print the archive index, fetch nothing
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

REPO_ROOT = Path(__file__).resolve().parents[2]
RAW_DIR = REPO_ROOT / "03_data" / "raw" / "opec_momr"
MANIFEST_PATH = REPO_ROOT / "03_data" / "manifest" / "document_index.jsonl"

UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
BASE = "https://publications.opec.org"
HOME_URL = f"{BASE}/momr"

ARCHIVE_LINK_RE = re.compile(r"/momr/archive/(\d+)/?$")
# Every month's page (including the current one) also renders a persistent nav
# sidebar whose links always point at the CURRENT report's /momr/chapter/<id>/<id>
# URLs, regardless of which month you're actually viewing — confirmed by scraping
# May 2018 (report 8) and finding its sidebar linked to report 159 (Jul 2026).
# The real per-month chapter links use /momr/archive/chapter/<report_id>/<chapter_id>
# (or plain /momr/chapter/<id>/<id> for the current month itself). Matching BOTH
# patterns and then filtering to report_id == the page's own report_id discards
# the nav-sidebar noise regardless of which pattern applies to a given month.
CHAPTER_LINK_RE = re.compile(r"/momr/(?:archive/)?chapter/(\d+)/(\d+)$")

# Footer boilerplate repeated on every page; stripped from saved chapter text.
FOOTER_MARKER = "OPEC Monthly Oil Market Report\nLinks"
HEADER_LINES = {"Main Page", "Account", "Chapters", "Information", "About MOMR", "Archive", "Download"}


def fetch(browser, url: str, retries: int = 2, settle_seconds: float = 1.0) -> tuple[int | None, str, list[dict]]:
    """Fetch a URL in a FRESH browser context (see module docstring for why).
    Returns (status_code, body_text, links)."""
    for attempt in range(1, retries + 2):
        context = browser.new_context(user_agent=UA)
        page = context.new_page()
        try:
            resp = page.goto(url, timeout=30000, wait_until="domcontentloaded")
            time.sleep(settle_seconds)
            status = resp.status if resp else None
            text = page.inner_text("body")
            links = page.evaluate(
                "() => Array.from(document.querySelectorAll('a')).map(a => "
                "({href: a.href, text: a.textContent.trim()}))"
            )
            return status, text, links
        except Exception as exc:  # noqa: BLE001
            print(f"  attempt {attempt} error on {url}: {exc}", file=sys.stderr)
        finally:
            context.close()
        time.sleep(2 * attempt)
    return None, "", []


def clean_chapter_text(text: str) -> str:
    if FOOTER_MARKER in text:
        text = text.split(FOOTER_MARKER)[0]
    lines = [ln for ln in text.splitlines() if ln.strip() not in HEADER_LINES]
    return "\n".join(lines).strip()


def discover_archive_index(browser) -> list[dict]:
    status, _text, links = fetch(browser, HOME_URL)
    if status != 200:
        print(f"ERROR: could not load archive index (status={status})", file=sys.stderr)
        return []
    seen: dict[str, dict] = {}
    for link in links:
        m = ARCHIVE_LINK_RE.search(link["href"])
        if m:
            report_id = m.group(1)
            period_label = " ".join(link["text"].split())
            seen[report_id] = {"report_id": report_id, "period_label": period_label, "url": link["href"]}
    return sorted(seen.values(), key=lambda r: int(r["report_id"]))


def discover_chapters(browser, report_url: str, expected_report_id: str) -> list[dict]:
    status, _text, links = fetch(browser, report_url)
    if status != 200:
        return []
    seen: dict[tuple[str, str], dict] = {}
    for link in links:
        m = CHAPTER_LINK_RE.search(link["href"])
        if not m:
            continue
        report_id, chapter_id = m.group(1), m.group(2)
        if report_id != expected_report_id:
            continue  # discard current-month nav-sidebar noise, see CHAPTER_LINK_RE comment
        title = " ".join(link["text"].split())
        seen[(report_id, chapter_id)] = {
            "report_id": report_id,
            "chapter_id": chapter_id,
            "title": title,
            "url": link["href"],
        }
    return list(seen.values())


def append_manifest_entry(entry: dict) -> None:
    MANIFEST_PATH.parent.mkdir(parents=True, exist_ok=True)
    with MANIFEST_PATH.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, ensure_ascii=False) + "\n")


def get_existing_manifest_doc_ids() -> set[str]:
    if not MANIFEST_PATH.exists():
        return set()
    ids = set()
    with MANIFEST_PATH.open(encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                try:
                    ids.add(json.loads(line)["doc_id"])
                except (json.JSONDecodeError, KeyError):
                    continue
    return ids


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--limit-months", type=int, default=None, help="Only process the first N discovered months")
    parser.add_argument("--discover-only", action="store_true", help="Print the archive index and exit")
    parser.add_argument("--sleep", type=float, default=1.5, help="Seconds to sleep between page fetches")
    args = parser.parse_args()

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)

        print("Discovering archive index...")
        months = discover_archive_index(browser)
        print(f"Found {len(months)} months in archive (publications.opec.org portal, 2018-present only).")

        if args.discover_only:
            print(json.dumps(months, indent=2, ensure_ascii=False))
            browser.close()
            return 0

        if args.limit_months:
            months = months[: args.limit_months]

        existing_ids = get_existing_manifest_doc_ids()
        n_chapters_ok, n_chapters_fail = 0, 0

        for month in months:
            report_id, period_label = month["report_id"], month["period_label"]
            print(f"\n=== {period_label} (report {report_id}) ===")
            time.sleep(args.sleep)
            chapters = discover_chapters(browser, month["url"], expected_report_id=report_id)
            print(f"  {len(chapters)} chapters found")

            for ch in chapters:
                doc_id = f"momr_{ch['report_id']}_{ch['chapter_id']}"
                if doc_id in existing_ids:
                    print(f"  SKIP {doc_id} (already in manifest)")
                    continue

                time.sleep(args.sleep)
                status, raw_text, _links = fetch(browser, ch["url"])
                if status != 200 or not raw_text:
                    print(f"  FAIL {doc_id}: status={status}")
                    n_chapters_fail += 1
                    continue

                cleaned = clean_chapter_text(raw_text)
                out_dir = RAW_DIR / report_id
                out_dir.mkdir(parents=True, exist_ok=True)
                out_path = out_dir / f"{ch['chapter_id']}.txt"
                out_path.write_text(cleaned, encoding="utf-8")

                append_manifest_entry(
                    {
                        "doc_id": doc_id,
                        "source_type": "momr_chapter",
                        "meeting_id": None,
                        "meeting_date": None,
                        "period_label": period_label,
                        "chapter_title": ch["title"],
                        "report_id": report_id,
                        "chapter_id": ch["chapter_id"],
                        "source_url": ch["url"],
                        "local_path": str(out_path.relative_to(REPO_ROOT)),
                    }
                )
                existing_ids.add(doc_id)
                n_chapters_ok += 1
                print(f"  OK {doc_id}: {ch['title']} ({len(cleaned)} chars)")

        browser.close()
        print(f"\nDone. chapters_ok={n_chapters_ok} chapters_fail={n_chapters_fail}")
        print(f"Manifest: {MANIFEST_PATH}")
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
