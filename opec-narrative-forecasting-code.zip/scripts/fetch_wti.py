"""Fetch current WTI observations without masquerading as the paper snapshot."""
import csv
from datetime import datetime, timezone
import os
from pathlib import Path
import requests

def main():
    key = os.environ.get('EIA_API_KEY')
    if not key:
        raise SystemExit('Set EIA_API_KEY using your own EIA registration.')
    rows = []
    params = {'api_key':key, 'frequency':'daily', 'data[0]':'value',
              'facets[series][]':'RWTC', 'sort[0][column]':'period',
              'sort[0][direction]':'asc', 'length':5000, 'offset':0}
    while True:
        try:
            response = requests.get('https://api.eia.gov/v2/petroleum/pri/spt/data/',
                                    params=params, timeout=60)
            if response.status_code != 200:
                raise SystemExit(f'EIA HTTP {response.status_code}; no file written.')
            payload = response.json()
        except (requests.RequestException, ValueError):
            raise SystemExit('EIA request failed; no file written. Check connectivity/key.') from None
        batch = payload.get('response', {}).get('data')
        if not isinstance(batch, list):
            raise SystemExit('Unexpected EIA response; no file written.')
        rows.extend(batch)
        if len(batch) < 5000:
            break
        params['offset'] += 5000
    if not rows:
        raise SystemExit('EIA returned no observations.')
    target = Path(__file__).resolve().parents[1] / '03_data/raw/eia'
    target.mkdir(parents=True, exist_ok=True)
    target /= 'wti_spot_daily_pulled' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '.csv'
    with target.open('x', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=['period','series','value'])
        writer.writeheader()
        writer.writerows({'period':r['period'], 'series':'RWTC', 'value':r.get('value')}
                         for r in rows)
    print(target)
    print('This is a new retrieval, not the archived 2026-07-24 snapshot.')

if __name__ == '__main__':
    main()
